// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../../nonnon/game/chara.c"
#include "../../nonnon/game/click.c"

#include "../../nonnon/win32/gdi.c"


#include "../../nonnon/neutral/bmp/ui/animated_counter.c"
#include "../../nonnon/neutral/bmp/ui/roundframe.c"


#include "cardgenerator.c"




//#define N_POKER_NO_GAMBLE




#ifdef DEBUG

//#define N_POKER_RESET_COIN

//#define N_POKER_WRITE_COIN

#else

#define N_POKER_WRITE_COIN

#endif



#define N_POKER_FONT_NAME n_posix_literal( "Trebuchet MS" )
//#define N_POKER_FONT_NAME n_posix_literal( "Hiragino Maru Gothic Pro" )




void
n_poker_rc_load( NSString *name, n_bmp *bmp, int scaler )
{

	n_bmp_free( bmp );


	NSBundle *main = [NSBundle mainBundle];
	NSString *path = [main pathForResource:name ofType:@"png"];
//NSLog( @"%@ : %@", name, path );

	NSImage *image = [[NSImage alloc] initWithContentsOfFile:path];
	if ( image == nil ) { NSLog( @"error" ); return; }

	n_mac_image_nsimage2nbmp( image, bmp );

	n_bmp_mac_color( bmp );


	int i = 0;
	n_posix_loop
	{
		if ( i >= scaler ) { break; }

		n_bmp_flush_antialias( bmp, 1.0 );
		n_bmp_flush_antialias( bmp, 1.0 );

		n_bmp_scaler_lil( bmp, 2 );

		i++;
	}


	return;
}




BOOL
n_poker_bmp_resampler_condition( n_bmp *bmp, n_type_real ratio_x, n_type_real ratio_y )
{

	// [!] : <limits.h> : LONG_MAX

	const n_type_real maxsize = (n_type_real) 0x7fffffff;


	n_type_gfx fsx = N_BMP_SX( bmp );
	n_type_gfx fsy = N_BMP_SY( bmp );

	n_type_real dsx = (n_type_real) fsx * ratio_x;
	n_type_real dsy = (n_type_real) fsy * ratio_y;

	if ( maxsize < trunc( dsx ) ) { return TRUE; }
	if ( maxsize < trunc( dsy ) ) { return TRUE; }


	n_type_gfx tsx = (n_type_gfx) round( dsx );
	n_type_gfx tsy = (n_type_gfx) round( dsy );

	if ( tsx <= 0 ) { return TRUE; }
	if ( tsy <= 0 ) { return TRUE; }

	if ( n_bmp_is_overflow( tsx, tsy ) ) { return TRUE; }


	return FALSE;
}

void
n_poker_bmp_back( n_bmp *bmp, u32 color_corner )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_gfx bmpsx = N_BMP_SX( bmp );
	n_type_gfx bmpsy = N_BMP_SY( bmp );

	n_type_gfx step = 16;
	n_type_gfx half = step / 2;

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		u32 color;

		n_bmp_ptr_get_fast( bmp, x, y, &color );

		if ( ( x % step ) < half )
		{
			color = n_bmp_blend_pixel( color, n_bmp_black, 0.1 );
		} else {
			color = n_bmp_blend_pixel( color, n_bmp_black, 0.2 );
		}

		if ( ( y % step ) < half )
		{
			color = n_bmp_blend_pixel( color, n_bmp_black, 0.1 );
		} else {
			color = n_bmp_blend_pixel( color, n_bmp_black, 0.2 );
		}

		n_bmp_ptr_set_fast( bmp, x, y, color );

		x++;
		if ( x >= bmpsx )
		{
			x = 0;

			y++;
			if ( y >= bmpsy ) { break; }
		}
	}


	n_bmp_cornermask( bmp, -25, 0, color_corner );


	return;
}




void
n_poker_button( n_bmp *bmp, n_posix_char *str, n_type_gfx sx, n_type_gfx sy, u32 color_bg, u32 color_fg )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                  = sx;
	gdi.sy                  = sy;

	gdi.base_color_bg       = color_bg;

	gdi.frame_style         = N_GDI_FRAME_ROUND;
	gdi.frame_round         = 8;

	gdi.text                = str;
	gdi.text_font           = N_POKER_FONT_NAME;
	gdi.text_size           = 16;
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_BOLD;
	gdi.text_color_main     = color_fg;


	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	return;
}




void
n_poker_label_result( n_bmp *bmp, n_posix_char *str )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.base_color_bg       = n_bmp_white_invisible;

	gdi.frame_style         = N_GDI_FRAME_ROUND;

	gdi.text                = str;
	gdi.text_font           = N_POKER_FONT_NAME;
	gdi.text_size           = 32;
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_BOLD;
	gdi.text_color_main     = n_bmp_white;


	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	return;
}




void
n_poker_joker_text( n_bmp *bmp, n_type_gfx text_size, u32 color )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                  = 0;
	gdi.sy                  = 0;

	gdi.base_color_bg       = n_bmp_white_invisible;

	gdi.text                = "Joker";
	gdi.text_font           = N_POKER_FONT_NAME;
	gdi.text_size           = text_size;
	gdi.text_style          = N_GDI_TEXT_SMOOTH;
	gdi.text_color_main     = color;


	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	return;
}




#define N_POKER_ANIMATION


#define N_POKER_CARD_ALL ( N_CARDGENERATOR_CARD_ALL + 1 ) // [!] : +1 for Joker
#define N_POKER_JOKER    N_CARDGENERATOR_CARD_ALL


#define N_POKER_PHASE_0_NONE ( 0 )
#define N_POKER_PHASE_0_INIT ( 1 )
#define N_POKER_PHASE_0_TURN ( 2 )
#define N_POKER_PHASE_1_HOLD ( 3 )
#define N_POKER_PHASE_2_TURN ( 4 )
#define N_POKER_PHASE_3_BACK ( 5 )
#define N_POKER_PHASE_4_BACK ( 6 )
#define N_POKER_PHASE_5_DONE ( 7 )
#define N_POKER_PHASE_5_OVER ( 8 )


#define N_POKER_COLOR_BG_LITE          n_bmp_rgb_mac( 111,111,111 )
#define N_POKER_COLOR_BG_DARK          n_bmp_rgb_mac(  50, 50, 50 )

#define N_POKER_COLOR_BUTTON_MAIN_DARK n_bmp_rgb_mac( 111,111,111 )
#define N_POKER_COLOR_BUTTON_MAIN_LITE n_bmp_rgb_mac( 222,222,222 )

#define N_POKER_COLOR_BUTTON_HOVER n_bmp_rgb_mac( 255,255,255 )


#define N_POKER_DRAW_CENTER_NONE ( 0 )
#define N_POKER_DRAW_CENTER_ALL  ( 1 )


#define N_POKER_GAME_MODE_ENDLESS ( 0 )
#define N_POKER_GAME_MODE_BET     ( 1 )
#define N_POKER_GAME_MODE_DEFAULT N_POKER_GAME_MODE_BET

#define N_POKER_COIN_DEFAULT      ( 500 )
#define N_POKER_BET_DEFAULT       ( 100 )




typedef struct {

	NonnonGame       *self;
	NSOperationQueue *queue;
	n_bmp             canvas;
	BOOL              refresh;
	int               draw_center;

	n_type_gfx        sx;
	n_type_gfx        sy;

	n_cardgenerator   cardgen;
	n_bmp             bmp_back;
	n_bmp             bmp_joker;

	u32               color_halo_hold;
	u32               color_halo_win1;
	u32               color_halo_win2;
	u32               color_button_accent;

	int               phase;
	u32               phase_timer;

	int               rule_result;
	int               rule_result_num_1;
	int               rule_result_num_2;
	BOOL              rule_result_joker;

	BOOL              click_onoff[ 2 ];
	BOOL              hover_onoff[ 2 ];

	int               game_mode;


	// [!] : game main

	int stock[ N_POKER_CARD_ALL ];
	int table[ 5 ];

	int stock_cursor;

	n_type_gfx tx[ 5 ];
	n_type_gfx ty[ 5 ];

	BOOL     hold[ 5 ];
	BOOL     back[ 5 ];
	int      side[ 5 ];

	n_bmp      button           [ 2 ];
	n_type_gfx button_x         [ 2 ];
	n_type_gfx button_y         [ 2 ];
	BOOL       button_is_clicked[ 2 ];
	n_type_gfx button_offset_y;
	n_type_gfx button_sy;

	n_bmp      label;
	n_type_gfx label_offset_y;

	int        turn_phase[ 5 ];
	u32        turn_timer[ 5 ];
	CGFloat    turn_delta[ 5 ];
	int        turn_deal_phase;

	BOOL       shortcut;

	n_bmp_ui_animated_counter coin_animated_counter;
	int                       coin;
	int                       coin_prv;
	int                       coin_pot;
	n_bmp                     coin_bmp;
	n_bmp                     coin_bmp_diff;
	int                       coin_dif;

} n_poker;


#define n_poker_zero( p ) n_memory_zero( p, sizeof( n_poker ) )




#define N_POKER_HIGH_CARD       ( 0 )
#define N_POKER_ROYAL_FLUSH     ( 1 )
#define N_POKER_STRAIGHT_FLUSH  ( 2 )
#define N_POKER_FIVE_OF_A_KIND  ( 3 )
#define N_POKER_FOUR_OF_A_KIND  ( 4 )
#define N_POKER_FULL_HOUSE      ( 5 )
#define N_POKER_FLUSH           ( 6 )
#define N_POKER_STRAIGHT        ( 7 )
#define N_POKER_THREE_OF_A_KIND ( 8 )
#define N_POKER_TWO_PAIR        ( 9 )
#define N_POKER_ONE_PAIR        ( 10 )




u32
n_poker_background_color( void )
{

	u32 color_bg;
	if ( n_mac_is_darkmode() )
	{
		color_bg = N_POKER_COLOR_BG_DARK;
	} else {
		color_bg = N_POKER_COLOR_BG_LITE;
	}

	return color_bg;
}

u32
n_poker_button_color( void )
{

	u32 color_bg;
	if ( n_mac_is_darkmode() )
	{
		color_bg = N_POKER_COLOR_BUTTON_MAIN_DARK;
	} else {
		color_bg = N_POKER_COLOR_BUTTON_MAIN_LITE;
	}

	return color_bg;
}

u32
n_poker_joker_text_color( void )
{

	u32 color_bg;
	if ( n_mac_is_darkmode() )
	{
		color_bg = n_bmp_white;
	} else {
		color_bg = N_POKER_COLOR_BG_DARK;
	}

	return color_bg;
}




int
n_poker_rule_shortcut( n_poker *p )
{

	int shortcut = 0;

	int i = 0;
	n_posix_loop
	{
		if ( p->hold[ i ] )
		{
			shortcut++;
		}

		i++;
		if ( i >= 5 ) { break; }
	}


	return ( shortcut == 5 );
}

#define N_SUIT_HEARTS   N_CARDGENERATOR_SUIT_HEARTS
#define N_SUIT_DIAMONDS N_CARDGENERATOR_SUIT_DIAMONDS
#define N_SUIT_SPADES   N_CARDGENERATOR_SUIT_SPADES
#define N_SUIT_CLUBS    N_CARDGENERATOR_SUIT_CLUBS
#define N_SUIT_MAX      N_CARDGENERATOR_SUIT_MAX

int
n_poker_rule_card_number( n_poker *p, int suit, int number )
{

	if ( suit == N_SUIT_HEARTS )
	{
		number += N_CARDGENERATOR_CARD_UNIT * 0;
	} else
	if ( suit == N_SUIT_DIAMONDS )
	{
		number += N_CARDGENERATOR_CARD_UNIT * 1;
	} else
	if ( suit == N_SUIT_SPADES )
	{
		number += N_CARDGENERATOR_CARD_UNIT * 2;
	} else
	if ( suit == N_SUIT_CLUBS )
	{
		number += N_CARDGENERATOR_CARD_UNIT * 3;
	}


	return number - 1;
}

#define n_poker_rule_is_hearts(   p, i ) n_poker_rule_range( p, i, N_SUIT_HEARTS,   N_SUIT_DIAMONDS )
#define n_poker_rule_is_diamonds( p, i ) n_poker_rule_range( p, i, N_SUIT_DIAMONDS, N_SUIT_SPADES   )
#define n_poker_rule_is_spades(   p, i ) n_poker_rule_range( p, i, N_SUIT_SPADES,   N_SUIT_CLUBS    )
#define n_poker_rule_is_clubs(    p, i ) n_poker_rule_range( p, i, N_SUIT_CLUBS,    N_SUIT_MAX      )

n_posix_bool
n_poker_is_joker( n_poker *p, int index )
{
//return TRUE;

	if ( index == N_POKER_JOKER ) { return TRUE; }

	return FALSE;
}

n_posix_bool
n_poker_rule_range( n_poker *p, int index, int f, int t )
{

	int data = p->table[ index ];
	int unit = N_CARDGENERATOR_CARD_UNIT;

	if ( ( data >= ( unit * f ) )&&( data < ( unit * t ) ) ) { return n_posix_true; }


	return n_posix_false;
}

int
n_poker_rule_number( n_poker *p, int index )
{

	int data = p->table[ index ];
	int unit = N_CARDGENERATOR_CARD_UNIT;

	if ( n_poker_rule_is_hearts  ( p, index ) ) { data -= unit * 0; } else
	if ( n_poker_rule_is_diamonds( p, index ) ) { data -= unit * 1; } else
	if ( n_poker_rule_is_spades  ( p, index ) ) { data -= unit * 2; } else
	if ( n_poker_rule_is_clubs   ( p, index ) ) { data -= unit * 3; }


	return data;
}

int
n_poker_rule_straight_base( n_poker *p, int reg[ 5 ] )
{

	int minim = 1;
	n_posix_loop
	{
		BOOL found = FALSE;

		int j = 0;
		n_posix_loop
		{
			if ( reg[ j ] == minim )
			{
				found = TRUE;
				break;
			}

			j++;
			if ( j >= 5 ) { break; }
		}

		if ( found == FALSE )
		{
			minim++;
		} else {
			break;
		}
	}
//NSLog( @"%d", minim );


	return minim;
}

BOOL
n_poker_rule_straight_next( n_poker *p, int reg[ 5 ], int minim, BOOL *joker_onoff )
{

	BOOL found = FALSE;

	int i = 0;
	n_posix_loop
	{
		if ( reg[ i ] == minim )
		{
			found = TRUE;
			break;
		}

		i++;
		if ( i >= 5 ) { break; }
	}

	if ( found == FALSE )
	{
		if ( (*joker_onoff) )
		{
			(*joker_onoff) = FALSE;
			return TRUE;
		}
	}


	return found;
}

void
n_poker_rule_result( n_poker *p )
{

	p->rule_result = N_POKER_HIGH_CARD;


	// [!] : Joker

	p->rule_result_joker = FALSE;

	int i = 0;
	n_posix_loop
	{//break;

		if ( n_poker_is_joker( p, p->table[ i ] ) ) { p->rule_result_joker = TRUE; }

		i++;
		if ( i >= 5 ) { break; }
	}
//NSLog( @"%d", joker_onoff );


	// [!] : Flush

	int h = 0;
	int d = 0;
	int s = 0;
	int c = 0;

	i = 0;
	n_posix_loop
	{//break;

		if ( n_poker_rule_is_hearts  ( p, i ) ) { h++; }
		if ( n_poker_rule_is_diamonds( p, i ) ) { d++; }
		if ( n_poker_rule_is_spades  ( p, i ) ) { s++; }
		if ( n_poker_rule_is_clubs   ( p, i ) ) { c++; }

		i++;
		if ( i >= 5 ) { break; }
	}

	if ( p->rule_result_joker )
	{
		if ( h == 4 ) { h = 5; }
		if ( d == 4 ) { d = 5; }
		if ( s == 4 ) { s = 5; }
		if ( c == 4 ) { c = 5; }
	}


	// [!] : Straight

	int reg[ 5 ];

	i = 0;
	n_posix_loop
	{

		int n = n_poker_rule_number( p, i );
		if ( n_poker_is_joker( p, p->table[ i ] ) ) { n = 99; }

		reg[ i ] = 1 + n;

//NSLog( @"Number : %d", reg[ i ] );

		i++;
		if ( i >= 5 ) { break; }
	}


	// [!] : DEBUG_RESULT : search with this word

	int straight = 0;


	// [!] : royal first

	BOOL royal_straight = FALSE;

	{
		BOOL joker_once = p->rule_result_joker;

		straight = 0;

//NSLog( @"1 : %d", joker_once );
		int next = 1; straight++;
		if ( n_poker_rule_straight_next( p, reg, next, &joker_once ) )
		{
//NSLog( @"2 : %d", joker_once );
			next = 10; straight++;
			if ( n_poker_rule_straight_next( p, reg, next, &joker_once ) )
			{
//NSLog( @"3 : %d", joker_once );
				next++; straight++;
				if ( n_poker_rule_straight_next( p, reg, next, &joker_once ) )
				{
//NSLog( @"4 : %d", joker_once );
					next++; straight++;
					if ( n_poker_rule_straight_next( p, reg, next, &joker_once ) )
					{
//NSLog( @"5 : %d", joker_once );
						next++; straight++;
						if ( n_poker_rule_straight_next( p, reg, next, &joker_once ) )
						{
							straight++;
							royal_straight = TRUE;
						}
					}
				}
			}
		}
	}

	if ( royal_straight == FALSE )
	{
		BOOL joker_once = p->rule_result_joker;

		straight = 0;

		int minim = n_poker_rule_straight_base( p, reg );
//NSLog( @"1 : %d %d", minim, joker_once );

		minim++; straight++;
		if ( n_poker_rule_straight_next( p, reg, minim, &joker_once ) )
		{
//NSLog( @"2 : %d %d", minim, joker_once );

			minim++; straight++;
			if ( n_poker_rule_straight_next( p, reg, minim, &joker_once ) )
			{
//NSLog( @"3 : %d %d", minim, joker_once );

				minim++; straight++;
				if ( n_poker_rule_straight_next( p, reg, minim, &joker_once ) )
				{
//NSLog( @"4 : %d %d", minim, joker_once );

					minim++; straight++;
					if ( n_poker_rule_straight_next( p, reg, minim, &joker_once ) )
					{
//NSLog( @"5 : %d %d", minim, joker_once );
						straight++;
					}
				}
			}
		}
	}

//NSLog( @"straight %d : royal %d", straight, royal_straight );


	// [!] : Pair

	int same[ 15 ] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };

	i = 0;
	n_posix_loop
	{

		int v = reg[ i ];
		if ( ( v >= 1 )&&( v <= 13 ) )
		{
			same[ v ]++;
		}

		i++;
		if ( i >= 5 ) { break; }
	}

	BOOL two   = FALSE;
	BOOL three = FALSE;
	BOOL four  = FALSE;
	BOOL five  = FALSE;

	int  pair  = 0;
	int  index = 0;
	int  indx2 = 0;

	BOOL joker_once = p->rule_result_joker;

	i = 0;
	n_posix_loop
	{

		if ( same[ i ] == 2 )
		{
			if ( joker_once )
			{
				joker_once = FALSE;
				three = TRUE;
			} else {
				two   = TRUE;
			}

			if ( pair == 0 )
			{
				index = i;
			} else {
				indx2 = i;
			}
			pair++;
		} else
		if ( same[ i ] == 3 )
		{
			if ( joker_once )
			{
				joker_once = FALSE;
				 four = TRUE;
			} else {
				three = TRUE;
			}
			index = i;
		} else
		if ( same[ i ] == 4 )
		{
			if ( joker_once )
			{
				joker_once = FALSE;
				five = TRUE;
			} else {
				four = TRUE;
			}
			index = i;
		}

		i++;
		if ( i > 13 ) { break; }
	}


	// [!] : Engine

//NSLog( @"%d : %d : %d %d %d %d", reg[ 0 ], straight, h, d, s, c );

	p->rule_result_num_1 = -1;
	p->rule_result_num_2 = -1;

	if ( 
		( royal_straight )
		&&
		(
			( h == 5 )
			||
			( d == 5 )
			||
			( s == 5 )
			||
			( c == 5 )
		)
	)
	{
		p->rule_result = N_POKER_ROYAL_FLUSH;

		p->rule_result_num_1 = -2;
	} else
	if (
		( straight == 5 )
		&&
		(
			( h == 5 )
			||
			( d == 5 )
			||
			( s == 5 )
			||
			( c == 5 )
		)
	)
	{
		p->rule_result = N_POKER_STRAIGHT_FLUSH;

		p->rule_result_num_1 = -2;
	} else
	if ( five )
	{
		p->rule_result = N_POKER_FIVE_OF_A_KIND;

		p->rule_result_num_1 = index - 1;
	} else
	if ( four )
	{
		p->rule_result = N_POKER_FOUR_OF_A_KIND;

		p->rule_result_num_1 = index - 1;
	} else
	if ( ( three )&&( two ) )
	{
		p->rule_result = N_POKER_FULL_HOUSE;

		p->rule_result_num_1 = -2;
	} else
	if (
		( h == 5 )
		||
		( d == 5 )
		||
		( s == 5 )
		||
		( c == 5 )
	)
	{
		p->rule_result = N_POKER_FLUSH;

		p->rule_result_num_1 = -2;
	} else
	if ( ( royal_straight )||( straight == 5 ) )
	{
		p->rule_result = N_POKER_STRAIGHT;

		p->rule_result_num_1 = -2;
	} else
	if ( three )
	{
		p->rule_result = N_POKER_THREE_OF_A_KIND;

		p->rule_result_num_1 = index - 1;
	} else
	if ( pair == 2 )
	{
		p->rule_result = N_POKER_TWO_PAIR;

		p->rule_result_num_1 = index - 1;
		p->rule_result_num_2 = indx2 - 1;
	} else
	if ( two )
	{
		p->rule_result = N_POKER_ONE_PAIR;

		p->rule_result_num_1 = index - 1;
	}


	return;
}

void
n_poker_rule_deal( n_poker *p )
{

	int i = 0;
	n_posix_loop
	{

		if ( p->hold[ i ] == FALSE )
		{
			p->table[ i ] = p->stock[ p->stock_cursor ];
			p->stock_cursor++;
		}

		i++;
		if ( i >= 5 ) { break; }
	}


	return;
}

void
n_poker_rule_score( n_poker *p )
{

	// [!] : odds without joker
	//
	//	ROYAL_FLUSH	 0.00015 % (approx)
	//	STRAIGHT_FLUSH	 0.0014  %
	//	FOUR_OF_A_KIND	 0.024   %
	//	FULL_HOUSE	 0.014   %
	//	FLUSH		 0.2     %
	//	STRAIGHT	 0.29    %
	//	THREE_OF_A_KIND	 2.11    %
	//	TWO_PAIR	 4.75    %
	//	ONE_PAIR	42.3     %
	//	HIGH_CARD	50.1     %


	int odds = 0;

	if ( p->rule_result == N_POKER_HIGH_CARD )
	{
		//
	} else
	if ( p->rule_result == N_POKER_ROYAL_FLUSH )
	{
		if ( p->rule_result_joker == FALSE )
		{
			odds = 100;
		} else {
			odds =  70;
		}
	} else
	if ( p->rule_result == N_POKER_STRAIGHT_FLUSH )
	{
		odds = 50;
	} else
	if ( p->rule_result == N_POKER_FIVE_OF_A_KIND )
	{
		odds = 30;
	} else
	if ( p->rule_result == N_POKER_FOUR_OF_A_KIND )
	{
		odds = 10;
	} else
	if ( p->rule_result == N_POKER_FULL_HOUSE )
	{
		odds = 9;
	} else
	if ( p->rule_result == N_POKER_FLUSH )
	{
		odds = 7;
	} else
	if ( p->rule_result == N_POKER_STRAIGHT )
	{
		odds = 5;
	} else
	if ( p->rule_result == N_POKER_THREE_OF_A_KIND )
	{
		odds = 3;
	} else
	if ( p->rule_result == N_POKER_TWO_PAIR )
	{
		odds = 2;
	} else
	if ( p->rule_result == N_POKER_ONE_PAIR )
	{
		//odds = 1;
	}


	int coin_get;

	if ( p->coin_pot == 0 )
	{
//NSLog( @"Normal" );
		coin_get = N_POKER_BET_DEFAULT * odds;
	} else {
//NSLog( @"Double Up" );
		coin_get = p->coin_pot * odds;
	}

	p->coin_prv = p->coin;

	p->coin += coin_get;

	p->coin_pot = coin_get;


	return;
}




BOOL
n_poker_highlight_onoff( n_poker *p, int i )
{

	BOOL ret = FALSE;

	if ( p->rule_result_num_1 == -2 ) { ret = TRUE; }

	int n = n_poker_rule_number( p, i );
	if ( p->rule_result_num_1 == n ) { ret = TRUE; }
	if ( p->rule_result_num_2 == n ) { ret = TRUE; }


	return ret;
}

BOOL
n_poker_highlight_joker_onoff( n_poker *p, int i )
{
//return TRUE;

	if ( FALSE == n_poker_is_joker( p, p->table[ i ] ) ) { return FALSE; }


	BOOL ret = FALSE;

	if ( ( p->rule_result >= N_POKER_ROYAL_FLUSH )&&( p->rule_result <= N_POKER_THREE_OF_A_KIND ) )
	{
		ret = TRUE;
	}


	return ret;
}




// internal
void
n_poker_on_click_debug( n_poker *p )
{

	n_type_gfx sx = N_BMP_SX( &p->cardgen.cards[ 0 ] );
	n_type_gfx sy = N_BMP_SY( &p->cardgen.cards[ 0 ] );

	int i = 0;
	n_posix_loop
	{

		CGFloat fx = p->tx[ i ];
		CGFloat fy = p->ty[ i ];

		n_bmp_box( &p->canvas, fx,fy,sx,sy, n_bmp_rgb_mac( 0,200,255 ) );

		i++;
		if ( i >= 5 ) { break; }
	}


	return;
}

void
n_poker_click_off( n_poker *p )
{

	p->click_onoff[ 0 ] = FALSE;
	p->click_onoff[ 1 ] = FALSE;

	p->button_is_clicked[ 0 ] = FALSE;
	p->button_is_clicked[ 1 ] = FALSE;

	return;
}

void
n_poker_on_click( n_poker *p )
{

	if ( p->phase == N_POKER_PHASE_5_DONE ) { return; }


	NSPoint pt = n_mac_cursor_position_get( p->self );

	pt.y = p->sy - pt.y;

	n_type_gfx sx = N_BMP_SX( &p->cardgen.cards[ 0 ] );
	n_type_gfx sy = N_BMP_SY( &p->cardgen.cards[ 0 ] );

	int i = 0;
	n_posix_loop
	{

		CGFloat fx = p->tx[ i ];
		CGFloat fy = p->ty[ i ];
		CGFloat tx = fx + sx;
		CGFloat ty = fy + sy;

		if ( ( fx < pt.x )&&( fy < pt.y )&&( tx > pt.x )&&( ty > pt.y ) )
		{
			if ( p->hold[ i ] )
			{
				p->hold[ i ] = FALSE;
			} else {
//NSLog( @"Hold #%d", i );
				p->hold[ i ] = TRUE;
			}
		}

		i++;
		if ( i >= 5 ) { break; }
	}


	return;
}

BOOL
n_poker_button_is_hovered( n_poker *p, n_type_gfx offset )
{

	if ( n_bmp_error( &p->button[ offset ] ) ) { return FALSE; }


	NSPoint pt = n_mac_cursor_position_get( p->self );

	pt.y = p->sy - 1 - pt.y;

	n_type_gfx sx = N_BMP_SX( &p->button[ offset ] );
	n_type_gfx sy = N_BMP_SY( &p->button[ offset ] );

	CGFloat fx = p->button_x[ offset ];
	CGFloat fy = p->button_y[ offset ];
	CGFloat tx = fx + sx;
	CGFloat ty = fy + sy;

	BOOL ret;

//NSLog( @"%0.0f %0.0f : %0.0f %0.0f : %0.0f %0.0f", fx, fy, pt.x, pt.y, tx, ty );
	if ( ( fx <= pt.x )&&( fy <= pt.y )&&( tx > pt.x )&&( ty > pt.y ) )
	{
		ret = TRUE;
	} else {
		ret = FALSE;
	}
//NSLog( @"%d", ret );


	return ret;
}




void
n_poker_bmp_halo( n_poker *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, u32 color )
{

	n_bmp *b = &p->cardgen.bmp_halo;

	n_type_gfx hsx = N_BMP_SX( b );
	n_type_gfx hsy = N_BMP_SY( b );

	n_type_gfx ox = sx - hsx; ox /= 2;
	n_type_gfx oy = sy - hsy; oy /= 2;

	n_bmp_rasterizer
	(
		b, &p->canvas,
		x+ox,y+oy, 
		color,
		n_posix_false
	);
/*
	n_bmp_transcopy
	(
		b, &p->canvas,
		0,0,hsx,hsy,
		x+ox,y+oy
	);
*/

	return;
}




void
n_poker_reset_turn( n_poker *p )
{

	int i = 0;
	n_posix_loop
	{
		p->turn_phase[ i ] = 0;
		p->turn_timer[ i ] = 0;
		p->turn_delta[ i ] = 0;

		i++;
		if ( i >= 5 ) { break; }
	}

	p->turn_deal_phase = 0;


	return;
}

void
n_poker_shuffle( n_poker *p )
{

	int i = 0;
	n_posix_loop
	{//break;
		int r = n_game_random( N_POKER_CARD_ALL );

		int       n   = p->stock[ r ];
		p->stock[ r ] = p->stock[ i ];
		p->stock[ i ] = n;

		i++;
		if ( i >= N_POKER_CARD_ALL ) { break; }
	}

	return;
}

void
n_poker_reset( n_poker *p )
{

	n_poker_shuffle( p );


	p->stock_cursor = 0;

	int i = 0;
	n_posix_loop
	{

		p->table[ i ] = p->stock[ p->stock_cursor ];
		p->stock_cursor++;

		i++;
		if ( i >= 5 ) { break; }
	}


#ifdef N_POKER_ANIMATION
	p->phase = N_POKER_PHASE_0_INIT;
#else
	p->phase = N_POKER_PHASE_1_HOLD;
#endif

	i = 0;
	n_posix_loop
	{
		if ( p->hold[ i ] )
		{
			p->hold[ i ] = FALSE;
		}

		p->turn_phase[ i ] = 0;
		p->turn_delta[ i ] = 0;

		i++;
		if ( i >= 5 ) { break; }
	}


	n_poker_rule_result( p );


	p->phase_timer = n_posix_tickcount();

	n_poker_reset_turn( p );

	p->shortcut = FALSE;


	p->draw_center = N_POKER_DRAW_CENTER_ALL;


	return;
}

void
n_poker_counter_init( n_poker *p )
{

	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.base_color_bg      = n_poker_background_color();

	gdi.text               = NULL;
	gdi.text_font          = N_POKER_FONT_NAME;
	gdi.text_size          = 28;
	gdi.text_color_main    = n_bmp_rgb_mac( 255,255,255 );
	gdi.text_style         = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_BOLD;

	n_bmp_ui_animated_counter_init( &p->coin_animated_counter, &gdi, 0 );


	return;
}

void
n_poker_counter_diff_make( n_poker *p )
{

	static int prv = -1;

	int d = p->coin - p->coin_dif;

	if ( d == prv ) { return; }
	prv = d;


	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.base_color_bg      = n_poker_background_color();

	gdi.text_font          = N_POKER_FONT_NAME;
	gdi.text_size          = 28;
	gdi.text_color_main    = n_bmp_rgb_mac( 255,255,255 );
	gdi.text_style         = N_GDI_TEXT_SMOOTH;


	n_posix_char str[ 1024 ];

	n_posix_sprintf_literal( str, "%+d", d );

	gdi.text = str;


	n_gdi_bmp( &gdi, &p->coin_bmp_diff );


	return;
}

void
n_poker_counter_diff_draw( n_poker *p, n_type_gfx x, n_type_gfx y )
{

	n_poker_counter_diff_make( p );

	n_bmp_transcopy
	(
		&p->coin_bmp_diff, &p->canvas,
		0,0,N_BMP_SX( &p->coin_bmp_diff ),N_BMP_SY( &p->coin_bmp_diff ),
		x - N_BMP_SX( &p->coin_bmp_diff ), y
	);


	return;
}

void
n_poker_cardgenerator( n_poker *p )
{

	n_posix_bool flip = n_bmp_flip_onoff;
	n_bmp_flip_onoff = n_posix_false;

	n_cardgenerator_exit( &p->cardgen     );
	n_cardgenerator_init( &p->cardgen, 14 );
	n_cardgenerator_loop( &p->cardgen     );

	n_bmp_flip_onoff = flip;


	// [!] : Back

	n_bmp_carboncopy( &p->cardgen.bmp_blank, &p->bmp_back );
	n_cardgenerator_resampler( &p->cardgen, &p->bmp_back, p->cardgen.color_frame );
	n_poker_bmp_back( &p->bmp_back, n_poker_background_color() );


	// [!] : Joker

	{
		n_bmp_free( &p->bmp_joker );
		n_bmp_carboncopy( &p->cardgen.bmp_blank, &p->bmp_joker );


		BOOL flip = n_bmp_flip_onoff;
		n_bmp_flip_onoff = n_posix_true;

		n_bmp bmp; n_bmp_zero( &bmp );
		n_poker_rc_load( @"rc/joker", &bmp, 1 );

		n_type_gfx fsx = N_BMP_SX( &bmp );
		n_type_gfx fsy = N_BMP_SY( &bmp );

		n_type_gfx tsx = N_BMP_SX( &p->bmp_joker );
		n_type_gfx tsy = N_BMP_SY( &p->bmp_joker );

		n_type_real ratio = (n_type_real) tsx / fsx;
		n_bmp_resampler( &bmp, ratio, ratio );

		fsx = N_BMP_SX( &bmp );
		fsy = N_BMP_SY( &bmp );

		n_type_gfx tx = n_game_centering( tsx, fsx );
		n_type_gfx ty = n_game_centering( tsy, fsy );

		n_bmp_transcopy
		(
			&bmp, &p->bmp_joker,
			0,0,fsx,fsy,
			tx,ty
		);

		n_bmp_free_fast( &bmp );


		n_cardgenerator_resampler( &p->cardgen, &p->bmp_joker , p->cardgen.color_frame );


		// [x] : buggy : timing error will happen

		//NSColor *nscolor = [NSColor textColor];
		//u32 color_text = n_mac_nscolor2argb( nscolor );

		n_bmp text; n_bmp_zero( &text );
		n_poker_joker_text( &text, 22, n_poker_joker_text_color() );

		fsx = N_BMP_SX( &text );
		fsy = N_BMP_SY( &text );

		tsx = N_BMP_SX( &p->bmp_joker );
		tsy = N_BMP_SY( &p->bmp_joker );

		n_bmp_transcopy
		(
			&text, &p->bmp_joker,
			0,0,fsx,fsy,
			8,8
		);

		n_bmp_flush_mirror( &text, N_BMP_MIRROR_ROTATE180 );

		n_bmp_transcopy
		(
			&text, &p->bmp_joker,
			0,0,fsx,fsy,
			tsx - fsx - 8, tsy - fsy - 8
		);

		n_bmp_free_fast( &text );


		n_bmp_flip_onoff = flip;

	}


	n_poker_counter_init( p );


	return;
}

void
n_poker_init( n_poker *p )
{
//NSLog( @"n_poker_init" );


	// Global #1

	n_bmp_safemode_base = n_bmp_safemode = n_posix_false;

	n_bmp_flip_onoff = TRUE;

	n_random_shuffle();

	//p->queue = [[NSOperationQueue alloc] init];


	// System

	p->sx = 777;
	p->sy = 333;

	n_bmp_new_fast( &p->canvas, p->sx, p->sy );

	n_poker_cardgenerator( p );

	{
		const n_type_gfx o = 24;

		n_type_gfx sx = N_BMP_SX( &p->cardgen.bmp_halo ) + o;
		n_type_gfx sy = N_BMP_SY( &p->cardgen.bmp_halo ) + o;

		n_bmp_resizer( &p->cardgen.bmp_halo, sx, sy, 0, N_BMP_RESIZER_CENTER );

		int i = 0;
		n_posix_loop
		{
			n_bmp_flush_antialias( &p->cardgen.bmp_halo, 1.0 );

			i++;
			if ( i > o ) { break; }
		}
	}

//n_bmp_save( &p->cardgen.cards[ 0 ], "/Users/nonnon2/Desktop/ret.bmp" );


	// Poker

	p->color_halo_win1 = n_bmp_rgb_mac( 255,255,  0 );
	p->color_halo_win2 = n_bmp_rgb_mac( 255,255,255 );


	{
		int i = 0;
		n_posix_loop
		{//break;
			n_poker_shuffle( p );

			i++;
			if ( i >= 100 ) { break; }
		}
	}

	{
		int i = 0;
		n_posix_loop
		{
			p->stock[ i ] = i;

			i++;
			if ( i >= N_POKER_CARD_ALL ) { break; }
		}
	}


	p->game_mode = N_POKER_GAME_MODE_DEFAULT;


	p->coin_pot = 0;

	n_poker_rc_load( @"rc/coin", &p->coin_bmp, 1 );
//n_bmp_save( &p->coin_bmp, "/Users/nonnon2/Desktop/ret.bmp" );


	n_poker_reset( p );


	return;
}

void
n_poker_background( n_poker *p )
{

	//NSColor *nscolor = [NSColor clearColor];
	//u32        color = n_mac_nscolor2argb( nscolor );

	n_bmp_flush( &p->canvas, n_poker_background_color() );


	return;
}

void
n_poker_table_draw_button_single( n_poker *p, n_posix_char *label )
{

	n_bmp_free( &p->button[ 1 ] );

	p->button_x[ 1 ] = -1000;
	p->button_y[ 1 ] = -1000;


	u32 bg = n_poker_button_color();
	u32 fg = n_poker_joker_text_color();


	int i = 0;

	n_poker_button( &p->button[ i ], label, p->sx / 5, 0, n_bmp_alpha_invisible_pixel( bg ), fg );


	n_type_gfx sx = N_BMP_SX( &p->button[ 0 ] );
	n_type_gfx sy = N_BMP_SY( &p->button[ 0 ] );

	p->button_x[ i ] = p->sx / 2;
	p->button_y[ i ] = p->button_offset_y + n_game_centering( p->sy - p->button_offset_y, sy );

	p->button_x[ i ] -= sx / 2;

	n_type_gfx pressed_y = p->button_y[ i ];
	if ( p->click_onoff[ i ] )
	{
		pressed_y += 2;
	}

	n_bmp_ui_roundframe_classic
	(
		&p->canvas,
		p->button_x[ i ], pressed_y, sx, sy,
		8, 1,
		p->color_button_accent,
		bg
	);

	n_bmp_transcopy
	(
		&p->button[ i ], &p->canvas,
		0,0,sx,sy,
		p->button_x[ i ], pressed_y
	);


	p->button_sy = sy;


	return;
}

void
n_poker_table_draw_button_double( n_poker *p, n_posix_char *label_1, n_posix_char *label_2 )
{

	int        i;
	n_type_gfx sx,sy;


	u32 bg = n_poker_button_color();
	u32 fg = n_poker_joker_text_color();


	// [!] : left button

	i = 0;

	n_poker_button( &p->button[ i ], label_1, p->sx / 5, 0, n_bmp_alpha_invisible_pixel( bg ), fg );

	sx = N_BMP_SX( &p->button[ i ] );
	sy = N_BMP_SY( &p->button[ i ] );

	p->button_x[ i ] = p->sx / 2;
	p->button_y[ i ] = p->button_offset_y + n_game_centering( p->sy - p->button_offset_y, sy );

	p->button_x[ i ] -= sx + 4;

	n_type_gfx pressed_y_1 = p->button_y[ i ];
	if ( p->click_onoff[ i ] )
	{
		pressed_y_1 += 2;
	}

	n_bmp_ui_roundframe_classic
	(
		&p->canvas,
		p->button_x[ i ], pressed_y_1, sx, sy,
		8, 1,
		p->color_button_accent,
		bg
	);

	n_bmp_transcopy
	(
		&p->button[ i ], &p->canvas,
		0,0,sx,sy,
		p->button_x[ i ], pressed_y_1
	);


	// [!] : right button

	i = 1;

	n_poker_button( &p->button[ i ], label_2, p->sx / 5, 0, n_bmp_alpha_invisible_pixel( bg ), fg );

	sx = N_BMP_SX( &p->button[ i ] );
	sy = N_BMP_SY( &p->button[ i ] );

	p->button_x[ i ] = p->sx / 2;
	p->button_y[ i ] = p->button_offset_y + n_game_centering( p->sy - p->button_offset_y, sy );

	p->button_x[ i ] += 4;

	n_type_gfx pressed_y_2 = p->button_y[ i ];
	if ( p->click_onoff[ i ] )
	{
		pressed_y_2 += 2;
	}

	n_bmp_ui_roundframe_classic
	(
		&p->canvas,
		p->button_x[ i ], pressed_y_2, sx, sy,
		8, 1,
		p->color_button_accent,
		bg
	);

	n_bmp_transcopy
	(
		&p->button[ i ], &p->canvas,
		0,0,sx,sy,
		p->button_x[ i ],pressed_y_2
	);


	p->button_sy = sy;


	return;
}

void
n_poker_draw_button_label( n_poker *p, n_posix_char *label_1, n_posix_char *label_2 )
{

	if (
		( n_posix_false == n_string_is_empty( label_1 ) )
		&&
		( n_posix_false == n_string_is_empty( label_2 ) )
	)
	{
		n_poker_table_draw_button_double( p, label_1, label_2 );
	} else {
		n_poker_table_draw_button_single( p, label_1 );
	}


	return;
}

void
n_poker_draw_button( n_poker *p )
{

	n_bmp_box
	(
		&p->canvas,
		0, p->button_offset_y + 10, p->sx, p->button_sy,
		n_poker_background_color()
	);

	if ( p->phase == N_POKER_PHASE_1_HOLD )
	{
		if ( p->game_mode == N_POKER_GAME_MODE_BET )
		{
			n_posix_char str1[ 100 ]; n_posix_sprintf_literal( str1, "Bet %d", N_POKER_BET_DEFAULT );
			n_posix_char str2[ 100 ];
			if ( p->coin_pot <= N_POKER_BET_DEFAULT )
			{
				p->coin_pot = 0;
				n_posix_sprintf_literal( str2, "" );
			} else {
				n_posix_sprintf_literal( str2, "Bet %d", p->coin_pot );
			}
			n_poker_draw_button_label( p, str1, str2 );
		} else {
			n_poker_draw_button_label( p, "Draw", "" );
		}
	} else
	if ( p->phase == N_POKER_PHASE_5_DONE )
	{
		n_poker_draw_button_label( p, "Next", "" );
	} else
	if ( p->phase == N_POKER_PHASE_5_OVER )
	{
		n_poker_draw_button_label( p, "Reset", "" );
	}


	return;
}

void
n_poker_table_draw_label( n_poker *p, n_posix_char *label )
{

	n_poker_label_result( &p->label, label );

	n_type_gfx sx = N_BMP_SX( &p->label );
	n_type_gfx sy = N_BMP_SY( &p->label );

	n_type_gfx x = n_game_centering( p->sx, sx );
	n_type_gfx y = n_game_centering( p->label_offset_y, sy );

	n_bmp_transcopy
	(
		&p->label, &p->canvas,
		0,0,sx,sy,
		x, y
	);


	return;
}

n_bmp*
n_poker_card_bmp( n_poker *p, int i )
{

	n_bmp *ret;

	int number = p->table[ i ];

	if ( n_poker_is_joker( p, number ) )
	{
		ret = &p->bmp_joker;
	} else {
		ret = &p->cardgen.cards[ number ];
	}


	return ret;
}

void
n_poker_card_draw_turn( n_poker *p, int i, n_type_gfx x, n_type_gfx y, n_bmp *target )
{
//if ( i != 0 ) { return; }


	if ( p->phase == N_POKER_PHASE_0_INIT )
	{
		//
	} else
	if ( p->back[ i ] == FALSE )
	{
		n_bmp *b = n_poker_card_bmp( p, i );
		n_bmp_transcopy
		(
			b, &p->canvas,
			0, 0, N_BMP_SX( b ), N_BMP_SY( b ),
			x, y
		);

		return;
	}


	const u32     msec = 25;
	const CGFloat step = 0.25;

	if ( n_game_timer( &p->turn_timer[ i ], msec ) )
	{
		p->turn_delta[ i ] += step;
		if ( p->turn_delta[ i ] > 1.0 )
		{
			p->turn_delta[ i ] = 1.0;
		}
	}


	CGFloat d = 0;

	BOOL blank = FALSE;

	if ( ( p->turn_phase[ i ] == 0 )||( p->turn_phase[ i ] == 2 ) )
	{
		d = 1.0 - p->turn_delta[ i ];
		if ( d < step )
		{
			d = step;
			p->turn_phase[ i ]++;
			p->turn_delta[ i ] = 0.0;
		}
	} else
	if ( ( p->turn_phase[ i ] == 1 )||( p->turn_phase[ i ] == 3 ) )
	{
		d = p->turn_delta[ i ];
		if ( d < step )
		{
			blank = TRUE;
		} else
		if ( d >= 1.0 )
		{
			d = 1.0;
			p->turn_phase[ i ]++;
			p->turn_delta[ i ] = 0.0;
		}
	} else {
//NSLog( @"!" );
		d = 1.0;
	}


	if ( blank )
	{
		//
	} else {
		n_bmp bmp; n_bmp_carboncopy( target, &bmp );

		n_bmp_resampler( &bmp, d, 1.0 );

		n_bmp_transcopy
		(
			&bmp, &p->canvas,
			0, 0, N_BMP_SX( &bmp ), N_BMP_SY( &bmp ),
			x + ( N_BMP_SX( target ) / 2 ) - ( N_BMP_SX( &bmp ) / 2 ), y
		);

		n_bmp_free_fast( &bmp );
	}


	return;
}

void
n_poker_table_draw_single_card( n_poker *p, int i, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, BOOL is_back )
{

	n_bmp *b;
	if ( is_back )
	{
		b = &p->bmp_back;
	} else {
		b = n_poker_card_bmp( p, i );
	}

	n_bmp_transcopy
	(
		b, &p->canvas,
		0,0,sx,sy,
		x,y
	);


	return;
}

void
n_poker_table_draw_coin_counter( n_poker *p )
{

	if ( p->game_mode == N_POKER_GAME_MODE_BET )
	{
		p->coin_animated_counter.figure = n_bmp_ui_animated_counter_figure_count( p->coin_prv );

		n_bmp_ui_animated_counter_loop_count( &p->coin_animated_counter, p->coin_prv );

		n_type_gfx x = 12;
		n_type_gfx y = 12;

		n_bmp_box
		(
			&p->canvas,
			x, y, N_BMP_SX( &p->coin_bmp ), N_BMP_SY( &p->coin_bmp ),
			n_poker_background_color()
		);

		n_bmp_transcopy
		(
			&p->coin_bmp, &p->canvas,
			0, 0, N_BMP_SX( &p->coin_bmp ), N_BMP_SY( &p->coin_bmp ),
			x, y
		);

		x += N_BMP_SX( &p->coin_bmp );
		y  = y + ( N_BMP_SY( &p->coin_bmp ) / 2 ) - ( N_BMP_SY( &p->coin_animated_counter.digit[ 0 ] ) / 2 );

		n_bmp_ui_animated_counter_loop_draw( &p->coin_animated_counter, &p->canvas, x,y );

		n_poker_counter_diff_draw( p, p->sx - 12, y );
	}


	return;
}

void
n_poker_table_draw( n_poker *p )
{

//p->draw_center = N_POKER_DRAW_CENTER_ALL;
	if ( p->draw_center == N_POKER_DRAW_CENTER_NONE ) { return; }


	p->draw_center = N_POKER_DRAW_CENTER_NONE;


	NSColor *nscolor_accent = [NSColor controlAccentColor];

	p->color_halo_hold     = n_bmp_color_mac( n_mac_nscolor2argb( nscolor_accent ) );

	p->color_button_accent = p->color_halo_hold;
	p->color_halo_hold     = n_bmp_vividness_tweak_pixel( p->color_halo_hold, 255 );


	n_poker_background( p );


	n_type_gfx sx = N_BMP_SX( &p->cardgen.cards[ 0 ] );
	n_type_gfx sy = N_BMP_SY( &p->cardgen.cards[ 0 ] );

	n_type_gfx gap = 16;

	n_type_gfx x = gap + ( ( p->sx - ( ( sx + gap ) * 5 ) ) / 2 );
	n_type_gfx y = ( p->sy / 2 ) - ( sy / 2 );

	p-> label_offset_y = y;
	p->button_offset_y = y + sy;

	BOOL back_timeout = FALSE;
	if ( n_game_timer( &p->phase_timer, 777 ) )
	{
		back_timeout = TRUE;
	}

	int next_phase = N_POKER_PHASE_0_NONE;

	int i = 0;
	n_posix_loop
	{
		if ( p->phase == N_POKER_PHASE_1_HOLD )
		{
			if ( p->hold[ i ] )
			{
				n_poker_bmp_halo( p, x,y,sx,sy, p->color_halo_hold );
			} else
			if (
				( n_poker_highlight_onoff( p, i ) )
				||
				( n_poker_highlight_joker_onoff( p, i ) )
			)
			{
				n_poker_bmp_halo( p, x,y,sx,sy, p->color_halo_win2 );
			}
		} else
		if ( p->phase == N_POKER_PHASE_2_TURN )
		{
			if ( p->hold[ i ] )
			{
				n_poker_bmp_halo( p, x,y,sx,sy, p->color_halo_hold );
			}
		} else
		if ( p->phase == N_POKER_PHASE_3_BACK )
		{
			if ( p->hold[ i ] )
			{
				n_poker_bmp_halo( p, x,y,sx,sy, p->color_halo_hold );
			}
		} else
		if ( p->phase == N_POKER_PHASE_5_DONE )
		{
			if (
				( n_poker_highlight_onoff( p, i ) )
				||
				( n_poker_highlight_joker_onoff( p, i ) )
			)
			{
				n_poker_bmp_halo( p, x,y,sx,sy, p->color_halo_win1 );
			}
		} else
		if ( p->phase == N_POKER_PHASE_5_OVER )
		{
			if ( n_poker_highlight_onoff( p, i ) )
			{
				n_poker_bmp_halo( p, x,y,sx,sy, p->color_halo_win1 );
			}
		}

		if ( ( p->phase == N_POKER_PHASE_0_INIT )||( p->phase == N_POKER_PHASE_2_TURN ) )
		{
			n_bmp *b = NULL;

			if ( p->shortcut )
			{
				n_poker_table_draw_single_card( p, i, x, y, sx, sy, p->back[ i ] );

				if ( p->phase == N_POKER_PHASE_0_INIT ) { next_phase = N_POKER_PHASE_1_HOLD; } else
				if ( p->phase == N_POKER_PHASE_2_TURN ) { next_phase = N_POKER_PHASE_4_BACK; }
			} else
			if ( p->turn_phase[ i ] == 0 )
			{
				BOOL back = FALSE;
				if ( p->phase == N_POKER_PHASE_0_INIT ) { back =         TRUE; } else
				if ( p->phase == N_POKER_PHASE_2_TURN ) { back = p->back[ i ]; }

				n_poker_table_draw_single_card( p, i, x, y, sx, sy, back );

				if ( back_timeout ) { p->turn_phase[ i ] = 2; }
			} else
			if ( p->turn_phase[ i ] == 2 )
			{
				b = &p->bmp_back;
				n_poker_card_draw_turn( p, i, x, y, b );

				if ( p->phase == N_POKER_PHASE_2_TURN )
				{
					if ( p->turn_deal_phase == 0 ) { p->turn_deal_phase = 1; }
				}
			} else
			if ( p->turn_phase[ i ] == 3 )
			{
				b = n_poker_card_bmp( p, i );
				n_poker_card_draw_turn( p, i, x, y, b );
			} else
			if ( p->turn_phase[ i ] == 4 )
			{
				b = n_poker_card_bmp( p, i );
				n_poker_card_draw_turn( p, i, x, y, b );

				if ( p->phase == N_POKER_PHASE_0_INIT ) { next_phase = N_POKER_PHASE_1_HOLD; } else
				if ( p->phase == N_POKER_PHASE_2_TURN ) { next_phase = N_POKER_PHASE_4_BACK; }
			}
		} else
/*
		if ( ( p->game_mode == N_POKER_GAME_MODE_BET )&&( p->coin <= 0 ) )
		{
			n_poker_table_draw_single_card( p, i, x, y, sx, sy, TRUE );
		} else
*/
		//
		{
			n_poker_table_draw_single_card( p, i, x, y, sx, sy, p->back[ i ] );
		}

		p->tx[ i ] = x;
		p->ty[ i ] = y;


		x += sx + gap;

		i++;
		if ( i >= 5 ) { break; }
	}

	if ( next_phase != N_POKER_PHASE_0_NONE )
	{
		p->phase = next_phase;
	}

	if ( p->turn_deal_phase == 1 )
	{
//NSLog( @"!" );
		p->turn_deal_phase = 2;
		n_poker_rule_deal( p );
	}


	n_poker_draw_button( p );


	if (
		( p->game_mode == N_POKER_GAME_MODE_BET )
		&&
		( p->phase == N_POKER_PHASE_5_OVER )
		&&
		( p->coin <= 0 )
	)
	{
		n_poker_table_draw_label( p, "Game Over" );
	} else
	if ( p->phase == N_POKER_PHASE_5_DONE )
	{
		n_posix_char str[ 1024 ];

		if (
			( p->game_mode == N_POKER_GAME_MODE_BET )
			&&
			( p->coin <= 0 )
		)
		{
			n_posix_sprintf_literal( str, "" );
		} else
		if ( p->rule_result == N_POKER_HIGH_CARD )
		{
			n_posix_sprintf_literal( str, "High card" );
		} else
		if ( p->rule_result == N_POKER_ROYAL_FLUSH )
		{
			n_posix_sprintf_literal( str, "Royal flush" );
		} else
		if ( p->rule_result == N_POKER_STRAIGHT_FLUSH )
		{
			n_posix_sprintf_literal( str, "Straight flush" );
		} else
		if ( p->rule_result == N_POKER_FIVE_OF_A_KIND )
		{
			n_posix_sprintf_literal( str, "Five of a kind" );
		} else
		if ( p->rule_result == N_POKER_FOUR_OF_A_KIND )
		{
			n_posix_sprintf_literal( str, "Four of a kind" );
		} else
		if ( p->rule_result == N_POKER_FULL_HOUSE )
		{
			n_posix_sprintf_literal( str, "Full house" );
		} else
		if ( p->rule_result == N_POKER_FLUSH )
		{
			n_posix_sprintf_literal( str, "Flush" );
		} else
		if ( p->rule_result == N_POKER_STRAIGHT )
		{
			n_posix_sprintf_literal( str, "Straight" );
		} else
		if ( p->rule_result == N_POKER_THREE_OF_A_KIND )
		{
			n_posix_sprintf_literal( str, "Three of a kind" );
		} else
		if ( p->rule_result == N_POKER_TWO_PAIR )
		{
			n_posix_sprintf_literal( str, "Two pair" );
		} else
		if ( p->rule_result == N_POKER_ONE_PAIR )
		{
			n_posix_sprintf_literal( str, "One pair" );
		}

		n_poker_table_draw_label( p, str );
	}


	n_poker_table_draw_coin_counter( p );


	p->refresh = TRUE;


	return;
}

void
n_poker_loop( n_poker *p )
{
//NSLog( @"n_poker_loop" );


	if ( p->phase == N_POKER_PHASE_0_INIT )
	{
//NSLog( @"N_POKER_PHASE_0_INIT" );

		n_label_init:

		p->draw_center = N_POKER_DRAW_CENTER_ALL;
		n_poker_table_draw( p );

		if ( p->phase == N_POKER_PHASE_1_HOLD )
		{
			p->draw_center = N_POKER_DRAW_CENTER_ALL;
		}

	} else
	if ( p->phase == N_POKER_PHASE_1_HOLD )
	{
//NSLog( @"N_POKER_PHASE_1_HOLD" );

		n_label_hold:

		n_poker_table_draw( p );

		if (
			( p->button_is_clicked[ 0 ] )
			||
			( p->button_is_clicked[ 1 ] )
		)
		{

			if ( p->button_is_clicked[ 0 ] ) { p->coin_pot = 0; }

			BOOL up = FALSE;
			if ( p->button_is_clicked[ 1 ] ) { up = TRUE; }
//NSLog( @"Up %d", up );

			n_poker_click_off( p );

			//n_posix_sleep( 100 );


			int i = 0;
			n_posix_loop
			{
				if ( p->hold[ i ] )
				{
					//p->hold[ i ] = FALSE;
				} else {
					p->back[ i ] = TRUE;
				}

				i++;
				if ( i >= 5 ) { break; }
			}

			p->phase_timer = n_posix_tickcount();
			p->shortcut    = n_poker_rule_shortcut( p );

			if ( p->game_mode == N_POKER_GAME_MODE_BET )
			{
				p->coin_prv = p->coin;

				if ( up )
				{
//NSLog( @"up : %d", p->coin_pot );
					p->coin -= p->coin_pot;
				} else {
//NSLog( @"no up" );
					p->coin -= N_POKER_BET_DEFAULT;
				}
			}

#ifdef N_POKER_ANIMATION
			p->phase = N_POKER_PHASE_2_TURN;
			n_poker_reset_turn( p );

			goto n_label_turn;
#else
			p->phase = N_POKER_PHASE_3_BACK;

			goto n_label_back;
#endif
		}

	} else
	if ( p->phase == N_POKER_PHASE_2_TURN )
	{
//NSLog( @"N_POKER_PHASE_2_TURN" );

		n_label_turn:

		p->draw_center = N_POKER_DRAW_CENTER_ALL;
		n_poker_table_draw( p );

	} else
	if ( p->phase == N_POKER_PHASE_3_BACK )
	{
//NSLog( @"N_POKER_PHASE_3_BACK" );

		// [!] : no animation mode only uses this

		n_label_back:

		if (
			( p->shortcut )
			||
			( n_game_timer( &p->phase_timer, 777 ) )
		)
		{
			p->phase = N_POKER_PHASE_5_DONE;

			int i = 0;
			n_posix_loop
			{
				p->back[ i ] = FALSE;

				i++;
				if ( i >= 5 ) { break; }
			}

			n_poker_rule_deal( p );
			n_poker_rule_result( p );

			if ( p->game_mode == N_POKER_GAME_MODE_BET )
			{
				n_poker_rule_score( p );
			}
		}

		p->draw_center = N_POKER_DRAW_CENTER_ALL;
		n_poker_table_draw( p );

	} else
	if ( p->phase == N_POKER_PHASE_4_BACK )
	{
//NSLog( @"N_POKER_PHASE_4_BACK" );

		// [!] : animation mode only uses this

		int i = 0;
		n_posix_loop
		{
			p->back[ i ] = FALSE;

			i++;
			if ( i >= 5 ) { break; }
		}

		//n_poker_rule_deal( p );
		n_poker_rule_result( p );

		if ( p->game_mode == N_POKER_GAME_MODE_BET )
		{
			n_poker_rule_score( p );
		}

		p->phase       = N_POKER_PHASE_5_DONE;
		p->draw_center = N_POKER_DRAW_CENTER_ALL;

		n_poker_table_draw( p );

	} else
	if ( p->phase == N_POKER_PHASE_5_DONE )
	{
//NSLog( @"N_POKER_PHASE_5_DONE" );

		if ( p->coin <= 0 )
		{
			p->phase = N_POKER_PHASE_5_OVER;

			p->draw_center = N_POKER_DRAW_CENTER_ALL;
			goto n_label_over;
		}

		n_poker_table_draw( p );

		if ( p->button_is_clicked[ 0 ] )
		{
//NSLog( @"N_MAC_KEYCODE_RETURN" );

			n_poker_click_off( p );

			//n_posix_sleep( 100 );

			n_poker_reset( p );

#ifdef N_POKER_ANIMATION
			goto n_label_init;
#else
			goto n_label_hold;
#endif
		}

	} else
	if ( p->phase == N_POKER_PHASE_5_OVER )
	{
//NSLog( @"N_POKER_PHASE_5_OVER" );

		n_label_over:

		n_poker_table_draw( p );

		if ( p->button_is_clicked[ 0 ] )
		{
			n_poker_click_off( p );

			//n_posix_sleep( 100 );

			p->coin     = N_POKER_COIN_DEFAULT;
			p->coin_prv = 0;
			p->coin_dif = p->coin;

			n_poker_reset( p );

#ifdef N_POKER_ANIMATION
			goto n_label_init;
#else
			goto n_label_hold;
#endif
		}

	}


	return;
}


