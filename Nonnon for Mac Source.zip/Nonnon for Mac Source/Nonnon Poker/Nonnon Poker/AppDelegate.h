//
//  AppDelegate.h
//  Nonnon Poker
//
//  Created by のんのん２ on 2024/12/18.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

