//
//  AppDelegate.m
//  Nyaagle
//
//  Created by のんのん on 2023/02/10.
//

#import "AppDelegate.h"



#include "../../nonnon/mac/n_textfield.c"
#include "../../nonnon/mac/n_txtbox.c"

#include "../../nonnon/neutral/bmp/ui/search_icon.c"


#include "engine.c"




@interface NyaagleImageView: NSImageView

@property (nonatomic,assign) id delegate;

@end

@implementation NyaagleImageView

@synthesize delegate;

- init
{
	self = [super init];
	if ( self )
	{
		[self registerForDraggedTypes:[NSArray arrayWithObject:NSPasteboardTypeFileURL]];
	}

	return self;
}




-(NSDragOperation) draggingEntered:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingEntered" );

	// [!] : call when hovered

	return NSDragOperationCopy;
}

-(void) draggingExited:( id <NSDraggingInfo> )sender
{
//NSLog( @"draggingExited" );
}

-(BOOL) prepareForDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"prepareForDragOperation" );

	return YES;
}

-(BOOL) performDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"performDragOperation" );

	return YES;
}

-(void) concludeDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"concludeDragOperation" );

	NSPasteboard *pasteboard = [sender draggingPasteboard];
	NSString     *nsstr      = [[NSURL URLFromPasteboard:pasteboard] path];

	[self.delegate NonnonDragAndDrop_dropped:nsstr];

}

-(NSDragOperation) draggingUpdated:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingUpdated" );

	return NSDragOperationCopy;
}




- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	if ( theEvent.clickCount >= 2 )
	{
		//[self.window zoom:self.window];

		NSRect rect = [self.window frame];

		CGFloat large_size = 777;

		rect.origin.x    -= ( large_size - rect.size.width  ) / 2;
		rect.origin.y    -= ( large_size - rect.size.height ) / 2;
		rect.size.width  = large_size;
		rect.size.height = large_size;

		[self.window setFrame:rect display:YES animate:YES];

		return;
	}

	[self.window performWindowDragWithEvent:theEvent];

}

@end




@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NyaagleImageView *n_logo;
@property (weak) IBOutlet NonnonTextField  *n_path;
@property (weak) IBOutlet NonnonTxtbox     *n_search;
@property (weak) IBOutlet NonnonTxtbox     *n_list;
@property (weak) IBOutlet NSMenuItem       *n_menu_file_name_only;

@property n_txt n_txt_data_search;
@property n_txt n_txt_data_list;

@end




@implementation AppDelegate {

	n_bmp search_icon;

	BOOL  n_is_option_pressed;

}




@synthesize n_txt_data_search;
@synthesize n_txt_data_list;




- (void) NyaagleLogo:(BOOL) is_text_search
{

	NSString *name;
	if ( is_text_search )
	{
		name = @"nyaagle_logo";
	} else {
		if ( n_mac_is_darkmode() )
		{
			name = @"nyaagle_logo_name_dark";
		} else {
			name = @"nyaagle_logo_name";
		}
	}

	NSBundle *main = [NSBundle mainBundle];
	NSString *path = [main pathForResource:name ofType:@"png"];

	NSImage  *img  = [[NSImage alloc] initWithContentsOfFile:path];

	_n_logo.image = img;

}

- (void) NyaagleGo
{

	_n_list.n_focus = -1;


	[[NSCursor operationNotAllowedCursor] set];


	n_posix_char *path  = n_mac_nsstring2str( [_n_path stringValue] );
	n_posix_char *query = n_txt_get( _n_search.n_txt_data, 0 );

	// [Needed] : sandbox off

	if ( n_posix_stat_is_file( path ) )
	{
		n_posix_char *upper = n_string_path_upperfolder_new( path );
		n_string_free( path );
		path = upper;
	}


	if ( n_posix_false == n_string_is_empty( query ) )
	{
		NSPasteboard *pasteboard = [NSPasteboard generalPasteboard];
		[pasteboard clearContents];
		[pasteboard writeObjects:@[ n_mac_str2nsstring( query ) ]];
	}


	n_posix_bool prv_search = n_nyaagle_is_text_search;

	if ( n_is_option_pressed )
	{
		n_nyaagle_is_text_search = n_posix_false;
	}

	[_n_list NonnonTxtboxReset];

	if ( ( n_txt_data_list.sy == 1 )&&( n_string_is_empty( n_txt_get( &n_txt_data_list, 0 ) ) ) )
	{
		n_txt_utf8_new( &n_txt_data_list );
		n_nyaagle_directory( &n_txt_data_list, path, query );
	} else {
		n_nyaagle_directory_narrowed( &n_txt_data_list, query );
	}
/*
	_n_list.n_line_offset = 0;

	if ( n_posix_false == n_txt_is_empty( &n_txt_data_list ) )
	{
		_n_list.n_line_offset = n_posix_strlen( path );
	}
*/

	n_nyaagle_is_text_search = prv_search;


	n_txt_sort_up( &n_txt_data_list );


	[_n_list display];

	n_string_free( path );


	[[NSCursor arrowCursor] set];


	return;
}

- (void) NonnonTxtbox_delegate_edited:(NonnonTxtbox*)txtbox onoff:(BOOL)onoff
{

	if ( txtbox == _n_search )
	{

		if ( _n_search.n_is_enter_pressed )
		{
			[self NyaagleGo];
		}

	}

}

- (void) NonnonTxtbox_delegate_F3:(NonnonTxtbox*)txtbox is_left:(BOOL)is_left
{
//NSLog( @"NonnonTxtbox_delegate_F3" );

	[self NyaagleGo];

}

- (void) NonnonTxtbox_delegate_delete:(NonnonTxtbox*)txtbox
{
//NSLog( @"NonnonTxtbox_delegate_delete" );

	n_txt_utf8_new( &n_txt_data_list );
	[_n_list NonnonTxtboxReset];

	[_n_list display];

}

- (void) NonnonTxtbox_delegate_shift:(NSEvent*) event
{
//NSLog( @"NonnonTxtbox_delegate_shift" );

	if ( n_nyaagle_is_text_search == FALSE ) { return; }

	if ( event.modifierFlags & NSEventModifierFlagOption )
	{
		n_is_option_pressed = TRUE;
		[self NyaagleLogo: NO];
	} else {
		n_is_option_pressed = FALSE;
		[self NyaagleLogo:YES];
	}


	return;
}




- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	if ( [theEvent clickCount] == 2 )
	{
		n_posix_char *path  = n_txt_get( &n_txt_data_list, _n_list.n_focus );
		NSString     *nsstr = n_mac_str2nsstring( path );

		if ( n_posix_stat_is_dir( path ) )
		{
			n_mac_finder_call( nsstr );
		} else {
			NSURL *nsurl = [NSURL fileURLWithPath:nsstr];
			[[NSWorkspace sharedWorkspace] openURL:nsurl];
		}
	}

}




- (void)NonnonDragAndDrop_dropped:(NSString*)nsstr
{
//NSLog( @"%@", nsstr );

	nsstr = n_textfield_path( nsstr, YES );

	[_n_path setStringValue:nsstr];


	n_txt_utf8_new( &n_txt_data_list );
	[_n_list NonnonTxtboxReset];
	[_n_list display];

}




- (void)awakeFromNib
{

	n_mac_image_window = _window;


	NSFont *font = n_mac_stdfont();


	_n_path.n_folder_only = TRUE;


	n_txt_zero( &n_txt_data_search );
	n_txt_utf8_new( &n_txt_data_search );

	_n_search.delegate_option     = N_MAC_TXTBOX_DELEGATE_EDITED | N_MAC_TXTBOX_DELEGATE_F3 | N_MAC_TXTBOX_DELEGATE_SHIFT | N_MAC_TXTBOX_DELEGATE_DELETE;
	_n_search.delegate            = self;
	_n_search.n_txt_data          = &n_txt_data_search;
	_n_search.n_mode              = N_MAC_TXTBOX_MODE_FINDBOX;
	_n_search.n_focus             = 0;
	_n_search.n_option_linenumber = N_MAC_TXTBOX_DRAW_LINENUMBER_NONE;

	[_n_search NonnonTxtboxFontChange:font];

	{
		n_bmp_zero( &search_icon );
		n_bmp_ui_search_icon_make( &search_icon, 1024, 0, n_bmp_black );

		_n_search.n_findbox_bmp_icon = &search_icon;
	}
/*
	// [!] : main icons maker
	{
		n_bmp bmp; n_bmp_zero( &bmp );

		n_bmp_ui_search_icon_make( &bmp, 1024, n_bmp_black, n_bmp_white );
n_bmp_ui_search_icon_png_save( &bmp, "/Users/nonnon2/Desktop/icon_main.png" );

		n_bmp_ui_search_icon_make( &bmp, 64, 0, n_bmp_rgb( 128,128,128 ) );
n_bmp_ui_search_icon_png_save( &bmp, "/Users/nonnon2/Desktop/icon_gray.png" );

		n_bmp_free_fast( &bmp );
	}
*/
	[_n_search NonnonTxtboxReset];


	n_txt_zero( &n_txt_data_list );
	n_txt_utf8_new( &n_txt_data_list );

	_n_list.delegate_option     = N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_LEFT;
	_n_list.delegate            = self;
	_n_list.n_mode              = N_MAC_TXTBOX_MODE_LISTBOX;
	_n_list.n_txt_data          = &n_txt_data_list;
	_n_list.n_option_linenumber = N_MAC_TXTBOX_DRAW_LINENUMBER_ONEBASED_INDEX;
	_n_list.n_listbox_no_edit   = TRUE;

	_n_list.n_listbox_no_selection_onoff = TRUE;

	_n_list.n_path_ellipsis_onoff = TRUE;

	[_n_list NonnonTxtboxFontChange:font];

	[_n_list NonnonTxtboxReset];


	_n_logo.delegate = self;


	// [!] : Xib constraints : misbehaves when size is small
	NSSize nssize = NSMakeSize( 512, 512 );
	[_window setContentMinSize:nssize];


	[self themeChanged:nil];

	[NSDistributedNotificationCenter.defaultCenter
	      addObserver: self
		 selector: @selector( themeChanged: )
		     name: @"AppleInterfaceThemeChangedNotification"
		   object: nil
	];


	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];
}

-(void)themeChanged:(NSNotification *) notification
{
//NSLog( @"themeChanged" );

	if ( n_mac_is_darkmode() )
	{
		self.window.backgroundColor = [NSColor windowBackgroundColor];
	} else {
		self.window.backgroundColor = [NSColor whiteColor];
	}

}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}




- (IBAction)n_menu_file_name_only:(id)sender {

	NSControlStateValue s = [_n_menu_file_name_only state];
	if ( s == NSControlStateValueOff )
	{
		[_n_menu_file_name_only setState:NSControlStateValueOn];
		n_nyaagle_is_text_search = n_posix_false;
	} else {
		[_n_menu_file_name_only setState:NSControlStateValueOff];
		n_nyaagle_is_text_search = n_posix_true;
	}

	[self NyaagleLogo:n_nyaagle_is_text_search];

}

- (IBAction)n_menu_readme:(id)sender {

	NSString *helpFilePath = [[NSBundle mainBundle] pathForResource:@"nyaagle" ofType:@"html"];
	NSURL    *helpFileURL  = [NSURL fileURLWithPath:helpFilePath];

	[[NSWorkspace sharedWorkspace] openURL:helpFileURL];

}




- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)app {
	return YES;
}


@end
