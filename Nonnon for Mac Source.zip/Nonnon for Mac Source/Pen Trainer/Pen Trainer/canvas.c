// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File




#ifndef _H_NONNON_MAC_NONNON_PAINT_CANVAS
#define _H_NONNON_MAC_NONNON_PAINT_CANVAS




#import <Cocoa/Cocoa.h>




#include "../../nonnon/mac/_mac.c"
#include "../../nonnon/mac/image.c"




#include "extern.c"




#define N_PAINT_CANVAS_MULTITHREAD




@protocol NonnonPaint_delegate

- (void) NonnonPaintResize;

@end




@interface NonnonPaintCanvas : NSView

@property (nonatomic,assign) id delegate;

@property n_paint *paint;
@property n_bmp    bmp_canvas;

- (NSPoint) n_paint_canvaspos;
- (int)     n_paint_zoom_get_int:(int) zoom;
- (void)    n_paint_convert_bitmap2canvas:(void*) zero x:(n_type_gfx*)x y:(n_type_gfx*)y  sx:(n_type_gfx*)sx sy:(n_type_gfx*)sy;
- (void)    display_optimized;

@end




static NonnonPaintCanvas *n_paint_global;




#include "pen.c"




@implementation NonnonPaintCanvas {

	NSPoint n_pt;

}


@synthesize delegate;

@synthesize paint;
@synthesize bmp_canvas;




- (instancetype)initWithCoder:(NSCoder *)coder
{
	self = [super initWithCoder:coder];

	if ( self )
	{
		[self registerForDraggedTypes:[NSArray arrayWithObject:NSPasteboardTypeFileURL]];

		n_bmp_zero( &bmp_canvas );

		n_paint_global = self;


		n_mac_timer_init( n_paint_global, @selector( n_paint_cursor_apply_timer_method ), 100 );

	}

	return self;
}




- (void) n_paint_cursor_apply_timer_method
{
	[self resetCursorRects];
}




- (BOOL) isFlipped
{
	return YES;
}

- (BOOL) acceptsFirstMouse:(NSEvent *)event
{
//NSLog( @"acceptsFirstMouse" );

	return YES;
}




- (void) display_optimized
{
//NSLog( @"display_optimized" );

	[self display];

}




- (void) PenTrainerUIDraw:(n_bmp*)bmp rect:(NSRect)rect hovered:(BOOL)hovered pressed:(BOOL)pressed
{

	{
		NSRect r = rect;

		n_mac_draw_roundrect( [NSColor grayColor], rect, 8 );
		r = NSInsetRect( rect, 1, 1 );

		NSColor *c = [NSColor controlBackgroundColor];
		if ( hovered )
		{
			c = n_mac_nscolor_blend( c, [NSColor controlAccentColor], 0.25 );
		}

		n_mac_draw_roundrect( c, r, 8 );
	}


	if ( pressed )
	{
		rect.origin.x++;
		rect.origin.y++;
	}

	n_mac_image_nbmp_direct_draw( bmp, &rect, NO );

}

-(void) PenTrainerIsHovered
{

	if ( paint->pen_start ) { return; }

	if ( n_mac_window_is_hovered_offset_by_rect( self, paint->clear_rect ) )
	{
		if ( paint->clear_is_hovered == FALSE )
		{
			paint->clear_is_hovered = TRUE;
			[self display];
		}
	} else {
		if ( paint->clear_is_hovered != FALSE )
		{
			paint->clear_is_hovered = FALSE;
			[self display];
		}
	}

	if ( n_mac_window_is_hovered_offset_by_rect( self, paint->prev_rect ) )
	{
		if ( paint->prev_is_hovered == FALSE )
		{
			paint->prev_is_hovered = TRUE;
			[self display];
		}
	} else {
		if ( paint->prev_is_hovered != FALSE )
		{
			paint->prev_is_hovered = FALSE;
			[self display];
		}
	}

	if ( n_mac_window_is_hovered_offset_by_rect( self, paint->next_rect ) )
	{
		if ( paint->next_is_hovered == FALSE )
		{
			paint->next_is_hovered = TRUE;
			[self display];
		}
	} else {
		if ( paint->next_is_hovered != FALSE )
		{
			paint->next_is_hovered = FALSE;
			[self display];
		}
	}

}




- (void) n_paint_draw:(void*) zero sx:(n_type_gfx)sx sy:(n_type_gfx)sy
{

	int zoom    = [self n_paint_zoom_get_int   :paint->zoom];
	int zoom_ui = [self n_paint_zoom_get_int_ui:paint->zoom];

	n_type_gfx bmpsx = N_BMP_SX( paint->pen_bmp_data );
	n_type_gfx bmpsy = N_BMP_SY( paint->pen_bmp_data );

	if ( paint->zoom < 0 )
	{
		bmpsx /= zoom;
		bmpsy /= zoom;
	} else {
		bmpsx *= zoom;
		bmpsy *= zoom;
	}

	n_type_gfx fx  = 0;
	n_type_gfx fy  = 0;
	n_type_gfx fsx = bmpsx;
	n_type_gfx fsy = bmpsy;
	n_type_gfx tx  = 0;
	n_type_gfx ty  = 0;


	if ( fsx > paint->inner_sx )
	{
		fx  = paint->scroll.x;
		fsx = paint->inner_sx;
	}

	if ( fsy > paint->inner_sy )
	{
		fy  = paint->scroll.y;
		fsy = paint->inner_sy;
	}

	paint->canvas_offset_x = tx = ( sx - fsx ) / 2;
	paint->canvas_offset_y = ty = ( sy - fsy ) / 2;

	paint->canvas_offset_sx = (CGFloat) fsx;
	paint->canvas_offset_sy = (CGFloat) fsy;


	// [!] : redraw area

	n_type_gfx rx;
	n_type_gfx ry;
	n_type_gfx rsx;
	n_type_gfx rsy;

	n_mac_rect_expand_size( paint->rect_redraw, &rx, &ry, &rsx, &rsy );


	rx  -= zoom_ui;
	ry  -= zoom_ui;
	rsx += zoom_ui;
	rsy += zoom_ui;


	// [!] : grid

	n_type_gfx center_x = bmpsx / 2;
	n_type_gfx center_y = bmpsy / 2;

	center_x /= zoom_ui;
	center_y /= zoom_ui;

	n_type_gfx grid_x = bmpsx / 8;
	n_type_gfx grid_y = bmpsx / 8;

	grid_x /= zoom_ui;
	grid_y /= zoom_ui;


	// [!] : optimization

	if ( paint->zoom < 0 )
	{
		fx = ( fx * zoom );
		fy = ( fy * zoom );
	} else {
		fx = ( fx / zoom );
		fy = ( fy / zoom );
	}


#ifdef N_PAINT_CANVAS_MULTITHREAD

	// [!] : multi-thread

	n_posix_bool prv = n_bmp_is_multithread;
	n_bmp_is_multithread = n_posix_true;

#endif // #ifdef N_PAINT_CANVAS_MULTITHREAD


	// [!] : Y axis

	n_type_gfx  y = 0;
	n_type_gfx zy = 0;
	n_posix_loop
	{


#ifdef N_PAINT_CANVAS_MULTITHREAD

	// [!] : multi-thread

	NSOperation *o = [NSBlockOperation blockOperationWithBlock:^{

#endif // #ifdef N_PAINT_CANVAS_MULTITHREAD


	// [!] : X axis : singleline

	n_type_gfx  x = 0;
	n_type_gfx zx = 0;
	n_posix_loop
	{

		if (
			( ( tx + x ) >= rx )
			&&
			( ( ty + y ) >= ry )
			&&
			( ( tx + x ) <= ( rx + rsx ) )
			&&
			( ( ty + y ) <= ( ry + rsy ) )
		)
		{

			n_type_gfx xx,yy;

			if ( self->paint->zoom < 0 )
			{
				xx = fx + ( x * zoom );
				yy = fy + ( y * zoom );
			} else {
				xx = fx + zx;
				yy = fy + zy;
			}

			u32 color = n_bmp_white;// n_bmp_ptr_get_fast( self->paint->pen_bmp_data, xx,yy, &color );

			if ( n_posix_false == n_bmp_ptr_is_accessible( self->paint->pen_bmp_data, xx,yy ) )
			{
				color = N_PAINT_CANVAS_COLOR;
			} else {
				n_bmp_ptr_get( self->paint->pen_bmp_data, xx,yy, &color );
			}
//color = n_bmp_rgb_mac( 0,200,255 );


			if ( zoom < 0 )
			{

				n_bmp_ptr_set_fast( &self->bmp_canvas, tx + x, ty + y, color );

			} else {
//n_bmp_box( &bmp_canvas, tx + x, ty + y, zoom_ui, zoom_ui, color );

				n_type_gfx bx = 0;
				n_type_gfx by = 0;
				n_posix_loop
				{//break;

					u32 c = color;


					// [!] : grid

					if ( ( self->paint->grid_onoff )&&( self->paint->zoom > 0 ) )
					{
						if ( ( xx == center_x )||( yy == center_y ) )
						{
							if ( ( bx == 0 )||( by == 0 )||( bx == ( zoom_ui - 1 ) )||( by == ( zoom_ui - 1 ) ) )
							{
								c = n_bmp_blend_pixel( c, n_bmp_rgb_mac( 255,0,128 ), 0.25 );
							}
						} else
						if ( ( ( xx % grid_x ) == 0 )||( ( yy % grid_y ) == 0 ) )
						{
							if ( ( bx == 0 )||( by == 0 )||( bx == ( zoom_ui - 1 ) )||( by == ( zoom_ui - 1 ) ) )
							{
								c = n_bmp_blend_pixel( c, n_bmp_rgb_mac( 0,200,255 ), 0.25 );
							}
						}
					}


					n_bmp_ptr_set( &self->bmp_canvas, tx + x + bx, ty + y + by, c );

					bx++;
					if ( bx >= zoom_ui )
					{
						bx = 0;

						by++;
						if ( by >= zoom_ui ) { break; }
					}
				}

			}

		}

		x += zoom_ui; zx++;
		if ( x >= fsx ) { break; }
	}


#ifdef N_PAINT_CANVAS_MULTITHREAD

	// [!] : multi-thread

	}];
	[paint->queue addOperation:o];

#endif // #ifdef N_PAINT_CANVAS_MULTITHREAD


	// [!] : Y axis

	y += zoom_ui; zy += 1;
	if ( y >= fsy ) { break; }

	}


#ifdef N_PAINT_CANVAS_MULTITHREAD

	// [!] : multi-thread

	[paint->queue waitUntilAllOperationsAreFinished];

	n_bmp_is_multithread = prv;

#endif // #ifdef N_PAINT_CANVAS_MULTITHREAD


	return;
}

-(void) drawRect:(NSRect) rect
{
//NSLog( @"drawRect" );


	// [x] : Sonoma : problem happens

	rect = [super bounds];


	// [Needed] : always needed

	[self n_paint_scroll_clamp];


	paint->rect_redraw = rect;


	BOOL is_flushed = FALSE;

	static n_type_gfx prv_sx = -1;
	static n_type_gfx prv_sy = -1;

	n_type_gfx sx = NSWidth ( self.frame ) + 1;
	n_type_gfx sy = NSHeight( self.frame ) + 1;

	if ( NULL == N_BMP_PTR( &bmp_canvas ) )
	{
		n_bmp_new_fast( &bmp_canvas, sx,sy );

		is_flushed = TRUE;
		n_bmp_flush( &bmp_canvas, N_PAINT_CANVAS_COLOR );
	}

	if ( ( prv_sx != sx )||( prv_sy != sy ) )
	{
		if ( is_flushed == FALSE )
		{
			n_bmp_flush( &bmp_canvas, N_PAINT_CANVAS_COLOR );
		}
	}


	static BOOL scroll_x_onoff = FALSE;
	static BOOL scroll_y_onoff = FALSE;

	BOOL prv_scroll_x_onoff = scroll_x_onoff;
	BOOL prv_scroll_y_onoff = scroll_y_onoff;


	if (
		( prv_scroll_x_onoff != scroll_x_onoff )
		||
		( prv_scroll_y_onoff != scroll_y_onoff )
	)
	{
		if ( is_flushed == FALSE )
		{
			n_bmp_flush( &bmp_canvas, N_PAINT_CANVAS_COLOR );
		}
	}


	// [!] : Combined Scale Copy

	[self n_paint_draw:nil sx:sx sy:sy];

	paint->redraw_type = N_PAINT_REDRAW_TYPE_ALL;


	{
		NSRect rect_canvas = NSMakeRect( 0,0,sx,sy );
		n_mac_image_nbmp_direct_draw( &bmp_canvas, &rect_canvas, NO );
	}


	[self PenTrainerUIDraw:&paint->clear_bmp rect:paint->clear_rect hovered:paint->clear_is_hovered pressed:paint->clear_is_pressed];
	[self PenTrainerUIDraw:&paint-> prev_bmp rect:paint-> prev_rect hovered:paint-> prev_is_hovered pressed:paint-> prev_is_pressed];
	[self PenTrainerUIDraw:&paint-> next_bmp rect:paint-> next_rect hovered:paint-> next_is_hovered pressed:paint-> next_is_pressed];


}




- (CGFloat) n_paint_zoom_get_ratio:(CGFloat) zoom
{
	if ( zoom < 0 ) { zoom = 1.0 / ( zoom * -1 ); }

//NSLog( @"%0.2f", zoom );
	return zoom;
}

- (int) n_paint_zoom_get_int:(int) zoom
{
	if ( zoom < 0 ) { zoom *= -1; }

//NSLog( @"%d", zoom );
	return zoom;
}

- (int) n_paint_zoom_get_int_ui:(int) zoom
{
	if ( zoom < 0 ) { zoom = 1; }

	return zoom;
}

- (NSPoint) n_paint_canvaspos
{

	// [Needed] : calc by integer is absolutely needed


	NSPoint pt = n_mac_cursor_position_get( self );

//NSLog( @"%f %f", pt.x, pt.y );

	n_type_gfx pt_x = pt.x;
	n_type_gfx pt_y = pt.y;


	pt_x -= paint->margin / 2;
	pt_y -= paint->margin / 2;

//NSLog( @"%f %f", pt.x, pt.y );


	n_type_real ratio = [self n_paint_zoom_get_ratio:paint->zoom];
	n_type_real zoom  = [self n_paint_zoom_get_int  :paint->zoom];


	n_type_gfx scr_x = paint->scroll.x;
	n_type_gfx scr_y = paint->scroll.y;

	if ( paint->zoom > 0 )
	{
		pt_x += scr_x / zoom * zoom;
		pt_y += scr_y / zoom * zoom;
	} else {
		pt_x += scr_x;
		pt_y += scr_y;
	}


	n_type_gfx bmpsx = N_BMP_SX( paint->pen_bmp_data ) * ratio;
	n_type_gfx bmpsy = N_BMP_SY( paint->pen_bmp_data ) * ratio;

	if ( paint->inner_sx > bmpsx )
	{
		pt_x -= ( paint->inner_sx - bmpsx ) / 2;
	}

	if ( paint->inner_sy > bmpsy )
	{
		pt_y -= ( paint->inner_sy - bmpsy ) / 2;
	}

	pt_x /= ratio;
	pt_y /= ratio;


	return NSMakePoint( pt_x, pt_y );
}

- (void) n_paint_convert_bitmap2canvas:(void*) zero x:(n_type_gfx*)x y:(n_type_gfx*)y sx:(n_type_gfx*)sx sy:(n_type_gfx*)sy
{

	CGFloat ratio = [self n_paint_zoom_get_ratio:paint->zoom];
//NSLog( @"%f", ratio );

	n_type_gfx osetx = paint->canvas_offset_x;
	n_type_gfx osety = paint->canvas_offset_y;
	n_type_gfx scr_x = paint->scroll.x;
	n_type_gfx scr_y = paint->scroll.y;
//NSLog( @"%d %d", osety ,scr_y );
//NSLog( @"%f", paint->scroll.y );

	if (  x != NULL ) { (* x) = osetx + ( (*x) * ratio ) - scr_x; }
	if (  y != NULL ) { (* y) = osety + ( (*y) * ratio ) - scr_y; }
	if ( sx != NULL ) { (*sx) = (*sx) * ratio; }
	if ( sy != NULL ) { (*sy) = (*sy) * ratio; }

}




- (void) n_paint_scroll_clamp
{

	if ( paint->scroll.x < 0 ) { paint->scroll.x = 0; }
	if ( paint->scroll.y < 0 ) { paint->scroll.y = 0; }

	CGFloat zoom = [self n_paint_zoom_get_ratio:paint->zoom];

	CGFloat max_sx = ( N_BMP_SX( paint->pen_bmp_data ) * zoom ) - paint->inner_sx + zoom;
	CGFloat max_sy = ( N_BMP_SY( paint->pen_bmp_data ) * zoom ) - paint->inner_sy + zoom;;

	if ( paint->scroll.x >= max_sx ) { paint->scroll.x = max_sx; }
	if ( paint->scroll.y >= max_sy ) { paint->scroll.y = max_sy; }

}




- (void) updateTrackingAreas
{
//return;

	int options = (
		NSTrackingMouseEnteredAndExited |
		NSTrackingMouseMoved            |
		NSTrackingActiveAlways          |
		NSTrackingActiveInActiveApp
	);

	NSTrackingArea *trackingArea = [
		[NSTrackingArea alloc]
			initWithRect:[self bounds]
			     options:options
			       owner:self
			    userInfo:nil
	];
	
	[self addTrackingArea:trackingArea];

}

- (void) resetCursorRects
{
//NSLog(@"resetCursorRects2");

//NSLog( @"%d", n_paint_frame_anim_onoff );


	if ( n_mac_window_is_hovered_offset_by_rect( self, paint->clear_rect ) )
	{
//NSLog( @"clear_rect" );
		[[NSCursor arrowCursor] set];
	} else
	if ( n_mac_window_is_hovered_offset_by_rect( self, paint->prev_rect ) )
	{
//NSLog( @"prev_rect" );
		[[NSCursor arrowCursor] set];
	} else
	if ( n_mac_window_is_hovered_offset_by_rect( self, paint->next_rect ) )
	{
//NSLog( @"next_rect" );
		[[NSCursor arrowCursor] set];
	} else
	if ( n_mac_window_is_hovered( self ) )
	{
		[[NSCursor crosshairCursor] set];
	} else {
		[[NSCursor arrowCursor] set];
	}

}

- (void) mouseEntered:(NSEvent *)theEvent
{
//NSLog(@"mouseEntered");

	// [Needed] : NSTrackingMouseEnteredAndExited

	[self.window makeKeyWindow];

}

- (void) mouseExited:(NSEvent *)theEvent
{
//NSLog(@"mouseExited");

	// [Needed] : NSTrackingMouseEnteredAndExited

	[self PenTrainerIsHovered];

}

- (void) mouseMoved:(NSEvent *)theEvent
{
//NSLog( @"mouseMoved" );

	// [Needed] : NSTrackingMouseMoved
	//[self.delegate mouseMoved:theEvent];

	[self PenTrainerIsHovered];

}




- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog( @"mouseUp" );


	if ( paint->readonly ) { return; }


	NonnonPaintPen_mouseUp( paint );

	if (
		( paint->clear_is_pressed )
		||
		( paint-> prev_is_pressed )
		||
		( paint-> next_is_pressed )
	)
	{
		paint->clear_is_pressed = FALSE;
		paint-> prev_is_pressed = FALSE;
		paint-> next_is_pressed = FALSE;

		[self display];
	} else {
		[self PenTrainerIsHovered];
	}

	[self resetCursorRects];

}

- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");


	if ( n_mac_window_is_hovered_offset_by_rect( self, paint->clear_rect ) )
	{
//NSLog( @"clear_rect" );
		extern void n_pentrainer_character_move( n_paint *paint, int delta );
		n_pentrainer_character_move( paint, 0 );

		paint->clear_is_pressed = TRUE;

		[self display];
	} else
	if ( n_mac_window_is_hovered_offset_by_rect( self, paint->prev_rect ) )
	{
//NSLog( @"prev_rect" );
		extern void n_pentrainer_character_move( n_paint *paint, int delta );
		n_pentrainer_character_move( paint, -1 );

		paint->prev_is_pressed = TRUE;

		[self display];
	} else
	if ( n_mac_window_is_hovered_offset_by_rect( self, paint->next_rect ) )
	{
//NSLog( @"next_rect" );
		extern void n_pentrainer_character_move( n_paint *paint, int delta );
		n_pentrainer_character_move( paint,  1 );

		paint->next_is_pressed = TRUE;

		[self display];
	} else {

		paint->pen_pressure = [theEvent pressure];

		NonnonPaintPen_mouseDown( paint );

		[self resetCursorRects];

	}

}

- (void) mouseDragged:(NSEvent*) theEvent
{
//NSLog( @"mouseDragged" );

	if ( paint->readonly ) { return; }

//NSLog( @"%f", [theEvent pressure] );

	paint->pen_pressure = [theEvent pressure];

	NonnonPaintPen_mouseDragged( paint );

	[self PenTrainerIsHovered];

}

- (void)rightMouseDown:(NSEvent *)theEvent
{
}


- (void)scrollWheel:(NSEvent *)theEvent
{
}




- (void) otherMouseUp:(NSEvent*) theEvent
{
//NSLog( @"otherMouseUp : %ld", (long) [theEvent buttonNumber] );
}

- (void) otherMouseDown:(NSEvent*) theEvent
{
//NSLog( @"otherMouseDown : %ld", (long) [theEvent buttonNumber] );
}

- (void) otherMouseDragged:(NSEvent*) theEvent
{
//NSLog( @"otherMouseDragged" );
}




- (BOOL)acceptsFirstResponder
{
//NSLog(@"acceptsFirstResponder");
	return YES;
}

- (BOOL)becomeFirstResponder
{
//NSLog(@"becomeFirstResponder");
        return YES;
}

- (void) keyDown : (NSEvent*) event
{
//NSLog( @"Key Code = %d", event.keyCode );

	// [!] : Pen Trainer

	[self.delegate keyDown:event];

}

- (void) keyUp : (NSEvent*) event
{
}




@end




#endif // _H_NONNON_MAC_NONNON_PAINT_CANVAS

