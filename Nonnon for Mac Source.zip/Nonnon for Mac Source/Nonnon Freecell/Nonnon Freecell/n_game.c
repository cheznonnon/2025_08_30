// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File


// [!] : Usage
//
//	1 : replace your NSView (Custom View) to NonnonGame
//	2 : IB : right pane : "Custom Class", "Class", set "NonnonGame"
//	3 : modify behavior


// [!] : trouble shooter
//
//	[ drawRect is not called at redraw ]
//
//		a : call [_n_game display];
//		b : see your @property and connect(DnD) to UI on the Xib canvas
//		c : layer may cause




#ifndef _H_NONNON_MAC_NONNON_GAME
#define _H_NONNON_MAC_NONNON_GAME




#import <Cocoa/Cocoa.h>


#include "../../nonnon/mac/_mac.c"
#include "../../nonnon/mac/image.c"
#include "../../nonnon/mac/sound.c"
#include "../../nonnon/mac/window.c"




//@interface NonnonGame : NSView <AVAudioPlayerDelegate>
@interface NonnonGame : NSView
@end




#include "nfreecell.c"




@interface NonnonGame ()

- (void) n_timer_method;

@end




@implementation NonnonGame {

	n_freecell freecell;
	    NSRect freecell_rect;
	      BOOL freecell_start;

}


- (instancetype)initWithCoder:(NSCoder *)coder
{
//NSLog( @"initWithCoder" );

	self = [super initWithCoder:coder];
	if ( self )
	{
//NSLog( @"initWithCoder" );
/*
		[[NSNotificationCenter defaultCenter]
			addObserver:self
			   selector:@selector( applicationWillBecomeActive: )
			       name:NSApplicationDidBecomeActiveNotification
			     object:nil
		];
*/
	}


	return self;
}

- (void) n_mac_game_init
{

	n_freecell_zero( &freecell );
	n_freecell_init( &freecell );
//NSLog( @"%d %d", freecell.sx, freecell.sy );

	//n_freecell_loop( &freecell );

	freecell.self = self;

	n_game_chara_cursor_position_mousemoved_init( self );


	// [x] : Sonoma : glitch prevention
	n_mac_timer_init_once( self, @selector( n_timer_method_launch ), 500 );

}


- (void) n_timer_method_launch
{
//NSLog( @"n_timer_method_launch" );

	n_freecell *p = &freecell;

	p->is_first = n_posix_true;

	n_mac_timer_init( self, @selector( n_timer_method ), 1 );

}


- (void) n_mac_game_canvas_resize:(NSWindow*)window width:(n_type_gfx)sx height:(n_type_gfx)sy
{
//NSLog( @"!" );

	if ( sx == -1 ) { sx = freecell.sx; }
	if ( sy == -1 ) { sy = freecell.sy; }
//NSLog( @"%d %d", sx, sy );

	NSSize size = NSMakeSize( sx,sy );

	[window setContentMinSize:size];
	//[window setContentMaxSize:size];

	freecell_rect = NSMakeRect( 0,0,sx,sy );
	[self setFrame:freecell_rect];

	[window setContentSize:size];
	n_mac_window_centering( window );

}

- (void) n_on_resize:(NSWindow*) window
{
//NSLog( @"n_on_resize" );

	n_freecell *p = &freecell;


	NSRect content = [window contentRectForFrameRect:window.frame];

	CGFloat sx = NSWidth ( content );
	CGFloat sy = NSHeight( content );

	freecell_rect = NSMakeRect( 0,0,sx,sy );
	[self setFrame:freecell_rect];

	p->cardgen.csx = p->sx = sx;
	p->cardgen.csy = p->sy = sy;


	{
		n_posix_bool prv = n_bmp_flip_onoff;
		n_bmp_flip_onoff = n_posix_true;

		n_bmp_new( &p->canvas, sx, sy );
		n_freecell_flush_background( p );

		n_bmp_flip_onoff = prv;
	}

	if ( p->animation_onoff )
	{
		n_freecell_animation_go( p, p->animation_index_f, p->animation_index_t );
	}

	n_freecell_reposition( p );
	n_freecell_redraw( p );

	p->refresh = TRUE;


	n_freecell_loop( p );
	[window display];

} 

- (void) n_accentColorChanged
{
//return;

	// [x] : memory leak : the system may have a bug


	n_freecell *p = &freecell;


	n_bmp_carboncopy( &p->canvas, &p->transition_bmp_old );

	n_freecell_style_change_color( p );
	n_freecell_flush_background( p );

	n_freecell_redraw( p );

	n_bmp_carboncopy( &p->bmp_bg, &p->transition_bmp_new );
	n_freecell_redirect( p, &p->transition_bmp_new );

	p->refresh = TRUE;
	n_freecell_loop( p );

	n_freecell_redirect( p, &p->canvas );


	p->transition_type  = N_GAME_TRANSITION_FADE;
	p->transition_onoff = TRUE;

}

- (void) n_darkModeChanged
{

	n_freecell *p = &freecell;


	n_bmp_carboncopy( &p->canvas, &p->transition_bmp_old );

	n_freecell_style_change_color( p );
	n_freecell_flush_background_cached( p );


	n_bmp_flip_onoff = n_posix_false;

	n_cardgenerator_exit( &p->cardgen     );
	n_cardgenerator_init( &p->cardgen, 10 );
	n_cardgenerator_loop( &p->cardgen     );

	n_freecell_cardgenerator( p );

	n_bmp_flip_onoff = n_posix_true;


	n_freecell_redraw( p );

	n_bmp_carboncopy( &p->bmp_bg, &p->transition_bmp_new );
	n_freecell_redirect( p, &p->transition_bmp_new );

	p->refresh = TRUE;
	n_freecell_loop( p );

	n_freecell_redirect( p, &p->canvas );


	p->transition_type  = N_GAME_TRANSITION_FADE;
	p->transition_onoff = TRUE;

}

- (void) n_game_start
{

	// [!] : macOS Sonoma launching sequence
	//
	//	initWithCoder
	//	awakeFromNib
	//	applicationWillFinishLaunching
	//	drawRect
	//	applicationDidFinishLaunching
	//	n_timer_method

}

/*
- (BOOL) isFlipped
{
	return YES;
}
*/

- (void) n_timer_method
{
//return;

//static u32 tick_prv = 0;


	// [x] : color / darkmode changer needs to be without this
	//if ( [n_mac_image_window isKeyWindow] == FALSE ) { return; }


	static u32 timer = 0;
	if ( n_game_timer( &timer, 12 ) )
	{
		NSPoint pt = n_mac_cursor_position_get( self );
		n_game_chara_cursor_position = n_mac_image_position_flip( &freecell.canvas, pt );

		n_freecell_loop( &freecell );
	}


	if ( freecell.refresh )
	{
//n_mac_debug_count();
		freecell.refresh = FALSE;

		[self display];
	}

//u32 tick_cur = n_posix_tickcount();

//NSLog( @"%d", (int) tick_cur - tick_prv );

//tick_prv = tick_cur;

}




- (void) drawRect:(NSRect) rect
{
//NSLog( @"drawRect" );

	n_mac_image_nbmp_direct_draw_fast( &freecell.canvas, &freecell_rect, n_posix_false );

}




- (void) mouseMoved:(NSEvent*) theEvent
{
//NSLog( @"mouseMoved" );
}

- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog( @"mouseUp" );

}

- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

#ifndef _H_NONNON_WIN32_GAME_CLICK

//NSLog( @"n_mac_doubleclick_detect()" );

	if ( n_mac_doubleclick_detect( &freecell.click_phase, &freecell.click_msec ) )
	{
		freecell.doubleclick = n_posix_true;
		n_freecell_loop( &freecell );
		freecell.doubleclick = n_posix_false;
	}

#endif

}




- (void) keyDown:(NSEvent*) theEvent
{
#ifdef DEBUG
	n_freecell_sound_play( &freecell, N_FREECELL_SOUND_FANFARE );
#endif
}




- (void) mouseDragged:(NSEvent*) theEvent
{
//NSLog(@"mouseDragged");

	NSPoint pt = [theEvent locationInWindow];
	n_game_chara_cursor_position = n_mac_image_position_flip( &freecell.canvas, pt );

	n_freecell_loop( &freecell );

//NSLog( @"%f %f", n_mac_is_input_cursor.x, n_mac_is_input_cursor.y );

}
/*
- (void) otherMouseDown:(NSEvent*) theEvent
{
//NSLog( @"otherMouseDown : %ld", (long) [theEvent buttonNumber] );

	// [!] : middle button

	if ( [theEvent buttonNumber] == 2 )
	{
		n_freecell_sound_play( &freecell, N_FREECELL_SOUND_FANFARE );
	}

}
*/



- (void) n_newgame
{
	n_freecell_newgame( &freecell );
}

- (void) n_replay
{
	n_freecell_replay( &freecell );
}


@end


#endif // _H_NONNON_MAC_NONNON_GAME


